document.addEventListener("DOMContentLoaded", function() {
    let canvas = document.getElementById("canvas");
    let ctx = canvas.getContext("2d");

    //Load Menu
    var gameMenu_main = new Image();
    gameMenu_main.src = "Images/menu.png";
    let startGame = false;
    var breakButton = new Image();
    breakButton.src = "Images/breakButton.png";
    //Load Credits
    var creditsScreen = new Image();
    creditsScreen.src = "Images/credits.png";
    let startCredits = false;
    //Load Settings
    var settingScreen = new Image();
    settingScreen.src = "Images/settings.png";
    let startSettings = false;

    //Load the map
    var layer_platform = new Image();
    layer_platform.src = "Images/Layer_Platformer.png";

    var layer_island = new Image();
    layer_island.src = "Images/Layer_Island.png";

    var layer_wather = new Image();
    layer_wather.src = "Images/Layer_Wather.png";

    var layer_sea = new Image();
    layer_sea.src = "Images/Layer_See.png";

    var layer_seaBorder = new Image();
    layer_seaBorder.src = "Images/Layer_See_Border.png";

    var layer_tree = new Image();
    layer_tree.src = "Images/Layer_Tree.png";

    var layer_bed = new Image();
    layer_bed.src = "Images/Layer_Bed.png";

    var layer_spawner = new Image();
    layer_spawner.src = "Images/Layer_Spawner.png";

    var layer_shop = new Image();
    layer_shop.src = "Images/Layer_Shops.png";

    var layer_IslandWay = new Image();
    layer_IslandWay.src = "Images/Layer_IslandWay.png";

    var layer_islandSpawner = new Image();
    layer_islandSpawner.src = "Images/Layer_IslandSpawner.png";

    var layer_bridge = new Image();
    layer_bridge.src = "Images/Layer_Bridge.png";

    //Load Player
    //-Load Player Mage:
    //--Walking
    //Front
    //Player 1 (Main)
    var playerWalkFront_1 = new Image();
    playerWalkFront_1.src = "Images/Character/1/front/1.png";
    var playerWalkFront_2 = new Image();
    playerWalkFront_2.src = "Images/Character/1/front/2.png";
    var playerWalkFront_3 = new Image();
    playerWalkFront_3.src = "Images/Character/1/front/3.png";
    var playerWalkFront_4 = new Image();
    playerWalkFront_4.src = "Images/Character/1/front/4.png";
    //Back
    var playerWalkBack_1 = new Image();
    playerWalkBack_1.src = "Images/Character/1/back/1.png";
    var playerWalkBack_2 = new Image();
    playerWalkBack_2.src = "Images/Character/1/back/2.png";
    var playerWalkBack_3 = new Image();
    playerWalkBack_3.src = "Images/Character/1/back/3.png";
    var playerWalkBack_4 = new Image();
    playerWalkBack_4.src = "Images/Character/1/back/4.png";
    //Left
    var playerWalkLeft_1 = new Image();
    playerWalkLeft_1.src = "Images/Character/1/left/1.png";
    var playerWalkLeft_2 = new Image();
    playerWalkLeft_2.src = "Images/Character/1/left/2.png";
    var playerWalkLeft_3 = new Image();
    playerWalkLeft_3.src = "Images/Character/1/left/3.png";
    var playerWalkLeft_4 = new Image();
    playerWalkLeft_4.src = "Images/Character/1/left/4.png";
    //Right
    var playerWalkRight_1 = new Image();
    playerWalkRight_1.src = "Images/Character/1/right/1.png";
    var playerWalkRight_2 = new Image();
    playerWalkRight_2.src = "Images/Character/1/right/2.png";
    var playerWalkRight_3 = new Image();
    playerWalkRight_3.src = "Images/Character/1/right/3.png";
    var playerWalkRight_4 = new Image();
    playerWalkRight_4.src = "Images/Character/1/right/4.png";
    //Player2
    //Down
    var player2WalkDown_1 = new Image();
    player2WalkDown_1.src = "Images/Character/2/down/1.png";
    var player2WalkDown_2 = new Image();
    player2WalkDown_2.src = "Images/Character/2/down/2.png";
    var player2WalkDown_3 = new Image();
    player2WalkDown_3.src = "Images/Character/2/down/3.png";
    var player2WalkDown_4 = new Image();
    player2WalkDown_4.src = "Images/Character/2/down/4.png";
    //Up
    var player2WalkUp_1 = new Image();
    player2WalkUp_1.src = "Images/Character/2/up/1.png";
    var player2WalkUp_2 = new Image();
    player2WalkUp_2.src = "Images/Character/2/up/2.png";
    var player2WalkUp_3 = new Image();
    player2WalkUp_3.src = "Images/Character/2/up/3.png";
    var player2WalkUp_4 = new Image();
    player2WalkUp_4.src = "Images/Character/2/up/4.png";
    //Left
    var player2WalkLeft_1 = new Image();
    player2WalkLeft_1.src = "Images/Character/2/left/1.png";
    var player2WalLeft_2 = new Image();
    player2WalLeft_2.src = "Images/Character/2/left/2.png";
    var player2WalkLeft_3 = new Image();
    player2WalkLeft_3.src = "Images/Character/2/left/3.png";
    var player2WalkLeft_4 = new Image();
    player2WalkLeft_4.src = "Images/Character/2/left/4.png";
    //Right
    var player2WalkRight_1 = new Image();
    player2WalkRight_1.src = "Images/Character/2/right/1.png";
    var player2WalRight_2 = new Image();
    player2WalRight_2.src = "Images/Character/2/right/2.png";
    var player2WalkRight_3 = new Image();
    player2WalkRight_3.src = "Images/Character/2/right/3.png";
    var player2WalkRight_4 = new Image();
    player2WalkRight_4.src = "Images/Character/2/right/4.png";
    //Player3
    //Down
    var player3WalkDown_1 = new Image();
    player3WalkDown_1.src = "Images/Character/3/down/1.png";
    var player3WalkDown_2 = new Image();
    player3WalkDown_2.src = "Images/Character/3/down/2.png";
    var player3WalkDown_3 = new Image();
    player3WalkDown_3.src = "Images/Character/3/down/3.png";
    var player3WalkDown_4 = new Image();
    player3WalkDown_4.src = "Images/Character/3/down/4.png";
    //Up
    var player3WalkUp_1 = new Image();
    player3WalkUp_1.src = "Images/Character/3/up/1.png";
    var player3WalkUp_2 = new Image();
    player3WalkUp_2.src = "Images/Character/3/up/2.png";
    var player3WalkUp_3 = new Image();
    player3WalkUp_3.src = "Images/Character/3/up/3.png";
    var player3WalkUp_4 = new Image();
    player3WalkUp_4.src = "Images/Character/3/up/4.png";
    //Left
    var player3WalkLeft_1 = new Image();
    player3WalkLeft_1.src = "Images/Character/3/left/1.png";
    var player3WalLeft_2 = new Image();
    player3WalLeft_2.src = "Images/Character/3/left/2.png";
    var player3WalkLeft_3 = new Image();
    player3WalkLeft_3.src = "Images/Character/3/left/3.png";
    var player3WalkLeft_4 = new Image();
    player3WalkLeft_4.src = "Images/Character/3/left/4.png";
    //Right
    var player3WalkRight_1 = new Image();
    player3WalkRight_1.src = "Images/Character/3/right/1.png";
    var player3WalRight_2 = new Image();
    player3WalRight_2.src = "Images/Character/3/right/2.png";
    var player3WalkRight_3 = new Image();
    player3WalkRight_3.src = "Images/Character/3/right/3.png";
    var player3WalkRight_4 = new Image();
    player3WalkRight_4.src = "Images/Character/3/right/4.png";
    //Player4
    //Down
    var player4WalkDown_1 = new Image();
    player4WalkDown_1.src = "Images/Character/4/down/1.png";
    var player4WalkDown_2 = new Image();
    player4WalkDown_2.src = "Images/Character/4/down/2.png";
    var player4WalkDown_3 = new Image();
    player4WalkDown_3.src = "Images/Character/4/down/3.png";
    var player4WalkDown_4 = new Image();
    player4WalkDown_4.src = "Images/Character/4/down/4.png";
    //Up
    var player4WalkUp_1 = new Image();
    player4WalkUp_1.src = "Images/Character/4/up/1.png";
    var player4WalkUp_2 = new Image();
    player4WalkUp_2.src = "Images/Character/4/up/2.png";
    var player4WalkUp_3 = new Image();
    player4WalkUp_3.src = "Images/Character/4/up/3.png";
    var player4WalkUp_4 = new Image();
    player4WalkUp_4.src = "Images/Character/4/up/4.png";
    //Left
    var player4WalkLeft_1 = new Image();
    player4WalkLeft_1.src = "Images/Character/4/left/1.png";
    var player4WalkLeft_2 = new Image();
    player4WalkLeft_2.src = "Images/Character/4/left/2.png";
    var player4WalkLeft_3 = new Image();
    player4WalkLeft_3.src = "Images/Character/4/left/3.png";
    var player4WalkLeft_4 = new Image();
    player4WalkLeft_4.src = "Images/Character/4/left/4.png";
    //Right
    var player4WalkRight_1 = new Image();
    player4WalkRight_1.src = "Images/Character/4/right/1.png";
    var player4WalkRight_2 = new Image();
    player4WalkRight_2.src = "Images/Character/4/right/2.png";
    var player4WalkRight_3 = new Image();
    player4WalkRight_3.src = "Images/Character/4/right/3.png";
    var player4WalkRight_4 = new Image();
    player4WalkRight_4.src = "Images/Character/4/right/4.png";

    //Load Mobile Controller
    var mobileController_default = new Image();
    mobileController_default.src = "Images/Controller/default.png";
    var mobileController_left = new Image();
    mobileController_left.src = "Images/Controller/left.png";
    var mobileController_right = new Image();
    mobileController_right.src = "Images/Controller/right.png";
    var mobileController_up = new Image();
    mobileController_up.src = "Images/Controller/up.png";
    var mobileController_down = new Image();
    mobileController_down.src = "Images/Controller/down.png";

    //Load Items
    var item_wood = new Image();
    item_wood.src = "Images/ItemsSpawn/wood.png";
    var item_stone = new Image();
    item_stone.src = "Images/ItemsSpawn/stone.png";
    var item_smaragd = new Image();
    item_smaragd.src = "Images/ItemsSpawn/smaragd.png";

    //ItemCount
    var item_count = new Image();
    item_count.src = "Images/ItemsSpawn/itemCounter.png";

    //Hearts
    var full_heart = new Image();
    full_heart.src = "Images/Heart/fullHeart.png";
    var half_heart = new Image();
    half_heart.src = "Images/Heart/halfHeart.png";
    var empty_heart = new Image();
    empty_heart.src = "Images/Heart/emptyHeart.png";

    //Shop
    var shop_img = new Image();
    shop_img.src = "Images/shop.png"
    var leatherIcon = new Image();
    leatherIcon.src = "Images/leatherIcon.png";
    var speedPoitionIcon = new Image();
    speedPoitionIcon.src = "Images/speedPoition.png";
    var bedIcon = new Image();
    bedIcon.src = "Images/bed.png"

    //Leathers
    var leather_forward = new Image();
    leather_forward.src = "Images/leathers/forward.png";

    let FootstepsVolume = 0.3;
    let UI_volume = 0.5
    let backgroundMusicVolume = 0.75;
    //SFX
    //Footsteps
    const FootstepsGrass = new Audio("SFX/Footsteps/Footsteps_Grass_03.wav");
    FootstepsGrass.volume = FootstepsVolume;
    const FootstepsStone = new Audio("SFX/Footsteps/Footsteps_Stone_Tiles_04.wav");
    FootstepsStone.volume = FootstepsVolume;
    const FootstepsWood = new Audio("SFX/Footsteps/Footsteps_Wood_Squeak_2.wav");
    FootstepsWood.volume = FootstepsVolume;
    //placeItem
    const placeItemSound = new Audio("SFX/placeItem.wav");
    placeItemSound.volume = UI_volume;
    //humanDeath
    const deathSound = new Audio("SFX/humanDeath.wav");
    deathSound.volume = UI_volume;
    //damage
    const demageSound = new Audio("SFX/damage.wav");
    demageSound.volume = UI_volume;
    //Get item
    const getItemSound = new Audio("SFX/getItem.wav");
    getItemSound.volume = UI_volume;
    //Bed destroyed
    const bedDestroyedSound = new Audio("SFX/bedDestroyd.wav");
    bedDestroyedSound.volume = UI_volume;
    //UI
    const ButtonPressed = new Audio("SFX/UI/buttonPressed.wav");
    ButtonPressed.volume = UI_volume;
    const buyItem = new Audio("SFX/UI/purchase.wav");
    buyItem.volume = UI_volume;
    const errorSound = new Audio("SFX/UI/error.wav");
    errorSound.volume = UI_volume;
    //Music
    const backgroundMusicSound = new Audio("SFX/backgroundMusic.wav");
    backgroundMusicSound.volume = backgroundMusicVolume;

    //Variables
    const zoom = 6;
    let map_x = -1900;
    let map_y = -3900;
    let mapPlayerUP_x = 2500;
    let mapPlayerUP_y = 70;
    const mapPlayerUP_x_StartPoint = 2500;
    const mapPlayerUP_y_StartPoint = 70;
    let previousPlayerUP_x = mapPlayerUP_x;
    let previousPlayerUP_y = mapPlayerUP_y;
    let gettingBackCount = 0;
    let playerUP_LifePoints = 10;
    let playerMain_LifePoints = 10;
    let playerUP_GetLifeBar = false;
    let playerUP_LifeBar = 60;
    let playerUP_attackPressed = false;
    let playerUP_diractionRight = false;
    let playerUP_diractionLeft = false;
    let playerUP_diractionUp = false;
    let playerUP_diractionDown = false;

    let player_x = 480;
    let player_y = 120;
    let player_speed = 3;
    const character_size = 155;
    let playerUP_speed = 3;
    let playerUP_count = 0;
    let playerUpWoodCounter_inv = 0;
    let playerUpStoneCounter_inv = 0;
    let playerUpSmaragdCounter_inv = 0;
    let playerUpActivateShop = false;
    let playerUPleatherCounter_inv = 0;
    let playerUP_countEnd = false;
    let playerUP_giveLeathers = false;
    let playerUP_gettingToMiddleEnd = false;
    let playerUP_gettingItemsMiddle = false;
    let playerUP_gettingBackBase = false;
    let playerUP_gettingBackMiddle = false;
    let playerUP_gettingMainPlayerBase = false;
    let playerUP_destroyBedBreakUp = false;
    let playerUP_bedAttack = false;
    let playerUP_bedLvl = 1;
    let RandInt_GetBaseOrMiddle = 0;
    let playerUP_bedState = 200;
    let playerMain_bedState = 200;
    let playerUP_bedBar = 60;
    let playerMain_bedBar = 60;
    let playerUP_break = false;

    let spawnWood = false;
    let spawnStone = false;
    let spawnSmaragd_1 = false;
    let spawnSmaragd_2 = false;
    let spawnSmaragd_3 = false;
    let spawnSmaragd_4 = false;
    let loop_wood = 0;
    let loop_stone = 0;
    let loopSmaragd_1 = 0;
    let loopSmaragd_2 = 0;
    let loopSmaragd_3 = 0;
    let loopSmaragd_4 = 0;
    let woodPrice = 5;
    let stonePrice = 60;
    let emeraldPrice = 30;

    let woodCounter = 0;
    let stoneCounter = 0;
    let smaragdCounter_1 = 0;
    let smaragdCounter_2 = 0;
    let smaragdCounter_3 = 0;
    let smaragdCounter_4 = 0;
    let woodCounter_inv = 0;
    let stoneCounter_inv = 0;
    let leatherCounter_inv = 0;
    let smaragdCounter_inv = 0;

    let activateShop = false;
    let speedPosionCount = 0;
    let activateSpeedPoision = false;
    let speedBoostApplied = false;
    let drawSpeedPoision = false;

    let leathersSet_1 = false;
    let leathersSet_2 = false;
    let leathersSet_3 = false;
    let leathersSet_4 = false;
    let leathersSet_5 = false;
    let leathersSet_6 = false;
    let leathersSet_7 = false;
    let leathersSet_8 = false;
    let leathersSet_9 = false;
    let leathersSet_10 = false;
    let leathersSet_11 = false;
    let leathersSet_12 = false;
    let leathersSet_13 = false;

    let PlayerUP_leathersSet_1 = false;
    let PlayerUP_leathersSet_2 = false;
    let PlayerUP_leathersSet_3 = false;
    let PlayerUP_leathersSet_4 = false;
    let PlayerUP_leathersSet_5 = false;
    let PlayerUP_leathersSet_6 = false;
    let PlayerUP_leathersSet_7 = false;
    let PlayerUP_leathersSet_8 = false;
    let PlayerUP_leathersSet_9 = false;
    let PlayerUP_leathersSet_10 = false;
    let PlayerUP_leathersSet_11 = false;
    let PlayerUP_leathersSet_12 = false;
    let PlayerUP_leathersSet_13 = false;
    
    let woodSpawnSpeed = 50;
    let stoneSpawnSpeed = 300;
    let smaragdSpawnSpeed = 500;

    let BedLvlPlayerMain = 1;

    let playerMove_Up = 0;
    let playerMove_Down = 0;
    let playerMove_Left = 0;
    let playerMove_Right = 0;

    let playerUpMove_Up = 0;
    let playerUpMove_Down = 0;
    let playerUpMove_Left = 0;
    let playerUpMove_Right = 0;

    let playerDircation_Up = false;
    let playerDircation_Down = true;
    let playerDircation_Left = false;
    let playerDircation_Right = false;
    let playerDircation_DownExtraCheck = false;

    let playerUP_MoveRightCount = 0;
    let playerUP_MoveLeftCount = 0;
    let playerUP_MoveUpCount = 0;
    let playerUP_MoveDownCount = 0;

    let playerUP_gettingItemsMiddleCheck = false;
    let playerUP_gettingBackBaseCheck = false;
    let playerUP_gettingBackMiddleCheck = false;
    let playerUP_gettingMainPlayerBaseCheck = false;
    let playerUP_bedAttackCheck = false;
    let playerUP_destroyBedBreakUpCheck = false;
    let playerUP_gettingToMiddleEndCheck = false;

    let WonGame = false;
    let LoseGame = false;

    let waterMove_x = 0;
    let playerIsMoving = false;
    let playerUP_breakPressed = false;

    // Function to resize the canvas
    function resizeCanvas() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }

    // Define the target FPS
    const targetFPS = 30;
    // Calculate the time interval between each frame
    const frameInterval = 1000 / targetFPS;

    canvas.addEventListener('mousemove', function(event) {
        const rect = canvas.getBoundingClientRect();
        const x = event.clientX - rect.left;
        const y = event.clientY - rect.top;
        //console.log(`PLAYER: x=${x}, y=${y}`);
        //MOVE PLAYER
        //UP
        playerIsMoving = false;
        
        if ((x > 70) && (x < 130) && (y > canvas.height-190) && (y < canvas.height-190+70)) {
            //console.log("MOVED1");
            player_y -= player_speed;
            playerMove_Up++;
            playerDircation_Up = true;
            playerDircation_Down = false;
            playerDircation_Left = false;
            playerDircation_Right = false;
            playerDircation_DownExtraCheck = false;
            console.log(playerMove_Up);
            playerIsMoving = true;
            if (playerMove_Up >= targetFPS) {
                playerMove_Up = 0;
            }
        }
        //DOWN
        else if ((x > 70) && (x < 130) && (y > canvas.height - 80) && (y < canvas.height - 80 + 70)) {
            //console.log("MOVED2");
            player_y += player_speed;
            playerMove_Down++;
            playerDircation_Up = false;
            playerDircation_Down = true;
            playerDircation_Left = false;
            playerDircation_Right = false;
            playerIsMoving = true;
            if (playerMove_Down >= targetFPS) {
                playerMove_Down = 0;
            }
        }
        //LEFT
        else if ((x > 10) && (x < 80) && (y > canvas.height - 130) && (y < canvas.height - 130 + 60)) {
            //console.log("MOVED3");
            player_x -= player_speed;
            playerMove_Left++;
            playerDircation_Up = false;
            playerDircation_Down = false;
            playerDircation_Left = true;
            playerDircation_Right = false;
            playerIsMoving = true;
            if (playerMove_Left >= targetFPS) {
                playerMove_Left = 0;
            }
        }
        //RIGHT
        else if ((x > 120) && (x < 190) && (y > canvas.height - 130) && (y < canvas.height - 130 + 60)) {
            //console.log("MOVED4");
            player_x += player_speed;
            playerMove_Right++;
            playerDircation_Up = false;
            playerDircation_Down = false;
            playerDircation_Left = false;
            playerDircation_Right = true;
            playerIsMoving = true;
            if (playerMove_Right >= targetFPS) {
                playerMove_Right = 0;
            }
        }
        if(!playerIsMoving) {
            playerDircation_Up = false;
            playerDircation_Down = true;
            playerDircation_Left = false;
            playerDircation_Right = false;
            playerIsMoving = false;
        }

        player_x = Math.max(0, Math.min(canvas.width - 50, player_x));
        player_y = Math.max(0, Math.min(canvas.height - 50, player_y));
    });

    // Function to update game state
    function update() {
        // Update game logic here
        //Camera
        if (player_x > canvas.width - 100) {
            map_x -= player_speed;
            player_x = canvas.width - 100;
        }
        if (player_x < 100) {
            map_x += player_speed;
            player_x = 100;
        }
        if (player_y > canvas.height - 100-100) {
            map_y -= player_speed;
            player_y = canvas.height - 200;
        }
        if (player_y < 100) {
            map_y += player_speed;
            player_y = 100;
        }

        playerBorder();

        ItemSpawnLogic();
        
        //Shop logic
        if ((map_x+2770 <= player_x) && (map_y+4070 >= player_y) &&
            (map_x+2770+140 >= player_x) && (map_y+4070-50 <= player_y)) {
            activateShop = true;
            player_y += 50;
            ButtonPressed.play();
        }

        //Leather
        //DOWN BASE
        if ((map_y+3820 >= player_y) && (map_x+2460 <= player_x) &&
            (map_y+3820-50 <= player_y) && (map_x+2460+380 >= player_x)) {
                console.log("SET LEATHER 1");
                if ((leatherCounter_inv > 0) && (leathersSet_1 == false)) {
                    leathersSet_1 = true;
                    leatherCounter_inv--;
                    placeItemSound.play();
                }
                if (leathersSet_1 == false) {
                    player_y += 50;
                }
        }
        if ((map_y+3820-100 >= player_y) && (map_x+2460 <= player_x) &&
            (map_y+3820-100-50 <= player_y) && (map_x+2460+380 >= player_x)) {
                console.log("SET LEATHER 2");
                if ((leatherCounter_inv > 0) && (leathersSet_2 == false)) {
                    leathersSet_2 = true;
                    leatherCounter_inv--;
                    placeItemSound.play();
                }
                if (leathersSet_2 == false) {
                    player_y += 50;
                }
        }
        if ((map_y+3820-100*2 >= player_y) && (map_x+2460 <= player_x) &&
            (map_y+3820-100*2-50 <= player_y) && (map_x+2460+380 >= player_x)) {
                console.log("SET LEATHER 3");
                if ((leatherCounter_inv > 0) && (leathersSet_3 == false)) {
                    leathersSet_3 = true;
                    leatherCounter_inv--;
                    placeItemSound.play();
                }
                if (leathersSet_3 == false) {
                    player_y += 50;
                }
        }
        if ((map_y+3820-100*3 >= player_y) && (map_x+2460 <= player_x) &&
            (map_y+3820-100*3-50 <= player_y) && (map_x+2460+380 >= player_x)) {
                console.log("SET LEATHER 4");
                if ((leatherCounter_inv > 0) && (leathersSet_4 == false)) {
                    leathersSet_4 = true;
                    leatherCounter_inv--;
                    placeItemSound.play();
                }
                if (leathersSet_4 == false) {
                    player_y += 50;
                }
        }
        if ((map_y+3820-100*4 >= player_y) && (map_x+2460 <= player_x) &&
            (map_y+3820-100*4-50 <= player_y) && (map_x+2460+380 >= player_x)) {
                console.log("SET LEATHER 5");
                if ((leatherCounter_inv > 0) && (leathersSet_5 == false)) {
                    leathersSet_5 = true;
                    leatherCounter_inv--;
                    placeItemSound.play();
                }
                if (leathersSet_5 == false) {
                    player_y += 50;
                }
        }
        if ((map_y+3820-100*5 >= player_y) && (map_x+2460 <= player_x) &&
            (map_y+3820-100*5-50 <= player_y) && (map_x+2460+380 >= player_x)) {
                console.log("SET LEATHER 6");
                if ((leatherCounter_inv > 0) && (leathersSet_6 == false)) {
                    leathersSet_6 = true;
                    leatherCounter_inv--;
                    placeItemSound.play();
                }
                if (leathersSet_6 == false) {
                    player_y += 50;
                }
        }
        if ((map_y+3820-100*6 >= player_y) && (map_x+2460 <= player_x) &&
            (map_y+3820-100*6-50 <= player_y) && (map_x+2460+380 >= player_x)) {
                console.log("SET LEATHER 7");
                if ((leatherCounter_inv > 0) && (leathersSet_7 == false)) {
                    leathersSet_7 = true;
                    leatherCounter_inv--;
                    placeItemSound.play();
                }
                if (leathersSet_7 == false) {
                    player_y += 50;
                }
        }
        if ((map_y+3820-100*7 >= player_y) && (map_x+2460 <= player_x) &&
            (map_y+3820-100*7-50 <= player_y) && (map_x+2460+380 >= player_x)) {
                console.log("SET LEATHER 8");
                if ((leatherCounter_inv > 0) && (leathersSet_8 == false)) {
                    leathersSet_8 = true;
                    leatherCounter_inv--;
                    placeItemSound.play();
                }
                if (leathersSet_8 == false) {
                    player_y += 50;
                }
        }
        if ((map_y+3820-100*8 >= player_y) && (map_x+2460 <= player_x) &&
            (map_y+3820-100*8-50 <= player_y) && (map_x+2460+380 >= player_x)) {
                console.log("SET LEATHER 9");
                if ((leatherCounter_inv > 0) && (leathersSet_9 == false)) {
                    leathersSet_9 = true;
                    leatherCounter_inv--;
                    placeItemSound.play();
                }
                if (leathersSet_9 == false) {
                    player_y += 50;
                }
        }
        if ((map_y+3820-100*9 >= player_y) && (map_x+2460 <= player_x) &&
            (map_y+3820-100*9-50 <= player_y) && (map_x+2460+380 >= player_x)) {
                console.log("SET LEATHER 10");
                if ((leatherCounter_inv > 0) && (leathersSet_10 == false)) {
                    leathersSet_10 = true;
                    leatherCounter_inv--;
                    placeItemSound.play();
                }
                if (leathersSet_10 == false) {
                    player_y += 50;
                }
        }
        if ((map_y+3820-100*10 >= player_y) && (map_x+2460 <= player_x) &&
            (map_y+3820-100*10-50 <= player_y) && (map_x+2460+380 >= player_x)) {
                console.log("SET LEATHER 11");
                if ((leatherCounter_inv > 0) && (leathersSet_11 == false)) {
                    leathersSet_11 = true;
                    leatherCounter_inv--;
                    placeItemSound.play();
                }
                if (leathersSet_11 == false) {
                    player_y += 50;
                }
        }
        if ((map_y+3820-100*11 >= player_y) && (map_x+2460 <= player_x) &&
            (map_y+3820-100*11-50 <= player_y) && (map_x+2460+380 >= player_x)) {
                console.log("SET LEATHER 12");
                if ((leatherCounter_inv > 0) && (leathersSet_12 == false)) {
                    leathersSet_12 = true;
                    leatherCounter_inv--;
                    placeItemSound.play();
                }
                if (leathersSet_12 == false) {
                    player_y += 50;
                }
        }
        if ((map_y+3820-100*12 >= player_y) && (map_x+2460 <= player_x) &&
            (map_y+3820-100*12-50 <= player_y) && (map_x+2460+380 >= player_x)) {
                console.log("SET LEATHER 13");
                if ((leatherCounter_inv > 0) && (leathersSet_13 == false)) {
                    leathersSet_13 = true;
                    leatherCounter_inv--;
                    placeItemSound.play();
                }
                if (leathersSet_13 == false) {
                    player_y += 50;
                }
        }

        //Speed Posion
        if (activateSpeedPoision) {
            console.log(speedPosionCount);
        }
        if (activateSpeedPoision && !speedBoostApplied) {
            player_speed += 3;
            speedBoostApplied = true;
        }
        if (speedPosionCount == 300) {
            speedPosionCount = 0;
            activateSpeedPoision = false;
            player_speed = 3;
            speedBoostApplied = false;
        }
        console.log(playerUP_count);

        if (startGame) {
            LoseGame = false;
            WonGame = false;
            playerUP_break = false;
        }
        if (!startGame) {
            playerUP_break = true;
        }
        if (!playerUP_break) {
            //PlayerUP Controller
            //Get Items 
            if (((playerUpWoodCounter_inv < woodPrice*13) && (!playerUP_gettingToMiddleEnd))) {
                console.log(playerUpWoodCounter_inv + " Wood Counter Player UP");
                if ((playerUP_count >= 0) && (playerUP_count <= 110)) {
                    mapPlayerUP_x -= playerUP_speed;
                }
            }
            if (((playerUpWoodCounter_inv > woodPrice*13) && (!playerUP_gettingToMiddleEnd))) {
                if (playerUP_count > 2000) {
                    playerUP_count = 0;
                }
                console.log("Start next step");
                if ((playerUP_count >= 0) && (playerUP_count <= 21)) {
                    mapPlayerUP_x += playerUP_speed;
                }
                if ((playerUP_count >= 22) && (playerUP_count <= 174)) {
                    mapPlayerUP_y += playerUP_speed;
                }
                //Buying leathers
                if ((playerUP_count >= 175) && (playerUP_count <= 190)) {
                    mapPlayerUP_x -= playerUP_speed;
                    if (!playerUP_giveLeathers) {
                        playerUPleatherCounter_inv += Math.round(playerUpWoodCounter_inv/woodPrice);
                        playerUP_giveLeathers = true;
                    }
                    console.log("Leather count " + playerUPleatherCounter_inv);
                }
                //Get Stones
                if ((playerUP_count >= 250) && (playerUP_count <= 450)) {
                    mapPlayerUP_x += playerUP_speed;
                }
                //Getting back and draw leathers
                if ((playerUP_count >= 451) && (playerUP_count <= 550)) {
                    mapPlayerUP_x -= playerUP_speed;
                }
                if ((playerUP_count >= 551) && (playerUP_count <= 565)) {
                    mapPlayerUP_y += playerUP_speed;
                }
                //Draw leathers
                if ((playerUP_count >= 566) && (playerUP_count <= 600)) {
                    mapPlayerUP_y += playerUP_speed;
                    PlayerUP_leathersSet_1 = true;
                }
                if (playerUP_count == 640) {
                    PlayerUP_leathersSet_2 = true;
                }
                if ((playerUP_count >= 640) && (playerUP_count <= 670)) {
                    mapPlayerUP_y += playerUP_speed;
                }
                if (playerUP_count == 671) {
                    PlayerUP_leathersSet_3 = true;
                }
                if ((playerUP_count >= 671) && (playerUP_count <= 700)) {
                    mapPlayerUP_y += playerUP_speed;
                }
                if (playerUP_count == 701) {
                    PlayerUP_leathersSet_4 = true;
                }
                if ((playerUP_count >= 701) && (playerUP_count <= 730)) {
                    mapPlayerUP_y += playerUP_speed;
                }
                if (playerUP_count == 731) {
                    PlayerUP_leathersSet_5 = true;
                }
                if ((playerUP_count >= 731) && (playerUP_count <= 760)) {
                    mapPlayerUP_y += playerUP_speed;
                }
                if (playerUP_count == 761) {
                    PlayerUP_leathersSet_6 = true;
                }
                if ((playerUP_count >= 761) && (playerUP_count <= 800)) {
                    mapPlayerUP_y += playerUP_speed;
                }
                if (playerUP_count == 801) {
                    PlayerUP_leathersSet_7 = true;
                }
                if ((playerUP_count >= 801) && (playerUP_count <= 830)) {
                    mapPlayerUP_y += playerUP_speed;
                }
                if (playerUP_count == 831) {
                    PlayerUP_leathersSet_8 = true;
                }
                if ((playerUP_count >= 831) && (playerUP_count <= 860)) {
                    mapPlayerUP_y += playerUP_speed;
                }
                if (playerUP_count == 861) {
                    PlayerUP_leathersSet_9 = true;
                }
                if ((playerUP_count >= 861) && (playerUP_count <= 900)) {
                    mapPlayerUP_y += playerUP_speed;
                }
                if (playerUP_count == 901) {
                    PlayerUP_leathersSet_10 = true;
                }
                if ((playerUP_count >= 901) && (playerUP_count <= 930)) {
                    mapPlayerUP_y += playerUP_speed;
                }
                if (playerUP_count == 931) {
                    PlayerUP_leathersSet_11 = true;
                }
                if ((playerUP_count >= 931) && (playerUP_count <= 960)) {
                    mapPlayerUP_y += playerUP_speed;
                }
                if (playerUP_count == 961) {
                    PlayerUP_leathersSet_12 = true;
                }
                if ((playerUP_count >= 961) && (playerUP_count <= 1000)) {
                    mapPlayerUP_y += playerUP_speed;
                }
                if (playerUP_count == 1001) {
                    PlayerUP_leathersSet_13 = true;
                }
                if ((playerUP_count >= 1001) && (playerUP_count <= 1090)) {
                    mapPlayerUP_y += playerUP_speed;
                }
                if (playerUP_count == 1091) {
                    playerUP_gettingToMiddleEnd = true;
                    playerUPleatherCounter_inv -= 13;
                    playerUP_gettingItemsMiddle = true;
                }
            }

            checkPlayerUpDirection();

            //LOOP
            //Getting smaragd
            if ((playerUP_gettingItemsMiddle) && (playerUP_gettingMainPlayerBase == false)) {
                playerUP_gettingBackMiddle = false;
                playerUP_destroyBedBreakUp = false;
                gettingBackCount = 0;
                if (playerUP_count > 930) {
                    playerUP_count = 0;
                }
                console.log("x: " + mapPlayerUP_x + " y: " + mapPlayerUP_y);
                if ((playerUP_count >= 0) && (playerUP_count <= 100)) {
                    mapPlayerUP_x -= playerUP_speed;
                }
                if (playerUP_count == 100) {
                    spawnSmaragd_2 = false;
                    playerUpSmaragdCounter_inv += smaragdCounter_2;
                    console.log("PlayerUP Smaragd Counter: " + playerUpSmaragdCounter_inv);
                    smaragdCounter_2 = 0;
                }
                if ((playerUP_count >= 101) && (playerUP_count <= 150)) {
                    mapPlayerUP_y += playerUP_speed;
                }
                if ((playerUP_count >= 151) && (playerUP_count <= 200)) {
                    mapPlayerUP_x += playerUP_speed;
                }
                if ((playerUP_count >= 201) && (playerUP_count <= 305)) {
                    mapPlayerUP_y += playerUP_speed;
                }
                if ((playerUP_count >= 306) && (playerUP_count <= 360)) {
                    mapPlayerUP_x -= playerUP_speed;
                }
                if (playerUP_count == 360) {
                    spawnSmaragd_1 = false;
                    playerUpSmaragdCounter_inv += smaragdCounter_1;
                    console.log("PlayerUP Smaragd Counter: " + playerUpSmaragdCounter_inv);
                    smaragdCounter_1 = 0;
                }
                if ((playerUP_count >= 370) && (playerUP_count <= 570)) {
                    mapPlayerUP_x += playerUP_speed;
                }
                if (playerUP_count == 570) {
                    spawnSmaragd_3 = false;
                    playerUpSmaragdCounter_inv += smaragdCounter_3;
                    console.log("PlayerUP Smaragd Counter: " + playerUpSmaragdCounter_inv);
                    smaragdCounter_3 = 0;
                }
                if ((playerUP_count >= 571) && (playerUP_count <= 620)) {
                    mapPlayerUP_x -= playerUP_speed;
                }
                if ((playerUP_count >= 621) && (playerUP_count <= 780)) {
                    mapPlayerUP_y -= playerUP_speed;
                }
                if ((playerUP_count >= 781) && (playerUP_count <= 830)) {
                    mapPlayerUP_x += playerUP_speed;
                }
                if (playerUP_count == 830) {
                    spawnSmaragd_4 = false;
                    playerUpSmaragdCounter_inv += smaragdCounter_4;
                    console.log("PlayerUP Smaragd Counter: " + playerUpSmaragdCounter_inv);
                    smaragdCounter_4 = 0;
                }
                if ((playerUP_count >= 831) && (playerUP_count <= 930)) {
                    mapPlayerUP_x -= playerUP_speed;
                }
                if (playerUP_count == 930) {
                    mapPlayerUP_x = 2488;
                    mapPlayerUP_y = 2032;
                    if (playerUpSmaragdCounter_inv >= 30) {
                        playerUP_gettingBackBase = true;
                    }
                }
            }
            //Getting back to Base
            if (playerUP_gettingBackBase) {
                playerUP_gettingItemsMiddle = false;
                if ((playerUP_count >= 931) && (playerUP_count <= 1420)) {
                    mapPlayerUP_y -= playerUP_speed;
                }
                if ((playerUP_count >= 1421) && (playerUP_count <= 1522)) {
                    mapPlayerUP_x -= playerUP_speed;
                }
                if (playerUP_count == 1523) {
                    playerUP_bedLvl ++;
                    playerUP_bedState += 200;
                    playerUP_bedBar = 60;
                    console.log("BED STATE: " + playerUP_bedState);
                    playerUP_gettingBackMiddle = true;
                    playerUpSmaragdCounter_inv -= emeraldPrice;
                }
            }
            //Getting back to Middle
            if (playerUP_gettingBackMiddle) {
                console.log("x: " + mapPlayerUP_x + "y: " + mapPlayerUP_y);
                playerUP_gettingBackBase = false;
                if ((playerUP_count >= 1524) && (playerUP_count <= 1625)) {
                    mapPlayerUP_x += playerUP_speed;
                }
                if ((playerUP_count >= 1626) && (playerUP_count <= 2115)) {
                    mapPlayerUP_y += playerUP_speed;
                }
                if (playerUP_count == 2115) {
                    RandInt_GetBaseOrMiddle = Math.round(Math.random());
                    console.log("Random Int: " + RandInt_GetBaseOrMiddle);
                    if (RandInt_GetBaseOrMiddle == 0) {
                        playerUP_gettingItemsMiddle = true;
                    }
                    if (RandInt_GetBaseOrMiddle == 1) {
                        playerUP_gettingMainPlayerBase = true;
                    }
                }
            }
            //Getting Main Player Base, Destroy Bed
            if (playerUP_gettingMainPlayerBase) {
                playerUP_gettingBackMiddle = false;
                playerUP_gettingItemsMiddle = false;
                if (!playerUP_gettingItemsMiddle) {
                    if (playerUP_count > 930) {
                        playerUP_count = 0;
                    }
                    if ((playerUP_count >= 0) && (playerUP_count <= 660)) {
                        mapPlayerUP_y += playerUP_speed;
                    }
                    if ((playerUP_count >= 661) && (playerUP_count <= 730)) {
                        mapPlayerUP_x -= playerUP_speed;
                    }
                    if ((playerUP_count >= 731) && (playerUP_count <= 880)) {
                        mapPlayerUP_y += playerUP_speed;
                    }
                    if ((playerUP_count >= 881) && (playerUP_count <= 930)) {
                        mapPlayerUP_x += playerUP_speed;
                    }
                    if ((playerUP_count == 930) && (playerMain_bedState > 0)) {
                        console.log("DESTROY BED");
                        playerUP_bedAttack = true;
                        bedDestroyedSound.play();
                    }
                    else {
                        playerUP_gettingItemsMiddle = true;
                    }
                }
            }
            if (playerUP_bedAttack) {
                playerUP_gettingMainPlayerBase = false;
                playerUP_gettingItemsMiddle = false;
                if (playerUP_count > playerMain_bedState) {
                    playerUP_count = 0;
                }
                if (playerMain_bedState >= 0) {
                    playerMain_bedState--;
                    console.log(playerMain_bedState);
                    if (playerMain_bedState > 0) {
                        playerMain_bedBar -= 0.3;
                        }
                    else {
                        playerMain_bedBar = 0;
                    }
                }
                else {
                    playerUP_destroyBedBreakUp = true;
                    BedLvlPlayerMain = 0;
                }
            }
            if (playerUP_destroyBedBreakUp) {
                playerUP_bedAttack = false;
                playerUP_gettingItemsMiddle = false;
                if ((playerUP_count >= 0) && (playerUP_count <= 49)) {
                    mapPlayerUP_x -= playerUP_speed;
                }
                if ((playerUP_count >= 50) && (playerUP_count <= 200)) {
                    mapPlayerUP_y -= playerUP_speed;
                }
                if ((playerUP_count >= 200) && (playerUP_count <= 269)) {
                    mapPlayerUP_x += playerUP_speed;
                }
                if ((playerUP_count >= 270) && (playerUP_count <= 930)) {
                    mapPlayerUP_y -= playerUP_speed;
                }
                if (playerUP_count == 930) {
                    playerUP_gettingItemsMiddle = true;
                }
            }
        }

        //MainPlayer Destroy Bed
        if ((map_y-50 <= player_y) && (map_x+1990+400 <= player_x) &&
            (map_y+100 >= player_y) && (map_x+1990+550 >= player_x)) {
            if (playerUP_bedState > 0) {
                console.log("Bed Destroying!!!");
                playerUP_bedState--;
                console.log(playerUP_bedState);
                if (playerUP_bedState > 0) {
                playerUP_bedBar -= 0.3;
                }
                else {
                    playerUP_bedBar = 0;
                    bedDestroyedSound.play();
                }
            }
            if (playerUP_bedState == 0) {
                playerUP_bedLvl = 0;
            }
        }
        //MainPlayer Attack PlayerUP
        if ((player_x > map_x+mapPlayerUP_x-70) && (player_y > map_y+mapPlayerUP_y-70) &&
            (player_x < map_x+mapPlayerUP_x+80) && (player_y < map_y+mapPlayerUP_y+80)) {
            console.log("Attack");
            playerUP_GetLifeBar = true;
            if ((playerUP_LifePoints > 0) && (playerUP_attackPressed)) {
                playerUP_LifePoints -= 0.5;
                playerUP_LifeBar -= 2.5;
                console.log(playerUP_LifePoints);
                console.log(playerUP_LifeBar);
                playerUP_attackPressed = false;
                demageSound.play();
            }
            if (playerUP_LifePoints <= 0) {
                deathSound.play();
                mapPlayerUP_x = 2182;
                mapPlayerUP_y = 562;
                playerUP_LifePoints = 10;
                playerUP_LifeBar = 60;
                playerUP_count = 1524;
                playerUP_break = false;
                playerUP_gettingItemsMiddle = false;
                playerUP_gettingBackBase = false;
                playerUP_gettingMainPlayerBase = false;
                playerUP_bedAttack = false;
                playerUP_destroyBedBreakUp = false;
                playerUP_gettingBackMiddle = true;
                if (playerUP_bedLvl === 0) {
                    startGame = false;
                    console.log("WON!!!");
                    WonGame = true;
                    //RESET
                    map_x = -1900;
                    map_y = -3900;
                    mapPlayerUP_x = 2500;
                    mapPlayerUP_y = 70;
                    gettingBackCount = 0;
                    playerUP_LifePoints = 10;
                    playerMain_LifePoints = 10;
                    playerUP_GetLifeBar = false;
                    playerUP_LifeBar = 60;
                    playerUP_attackPressed = false;
                    player_x = 480;
                    player_y = 120;
                    player_speed = 3;
                    playerUP_speed = 3;
                    playerUP_count = 0;
                    playerUpWoodCounter_inv = 0;
                    playerUpStoneCounter_inv = 0;
                    playerUpSmaragdCounter_inv = 0;
                    playerUpActivateShop = false;
                    playerUPleatherCounter_inv = 0;
                    playerUP_countEnd = false;
                    playerUP_giveLeathers = false;
                    playerUP_gettingToMiddleEnd = false;
                    playerUP_gettingItemsMiddle = false;
                    playerUP_gettingBackBase = false;
                    playerUP_gettingBackMiddle = false;
                    playerUP_gettingMainPlayerBase = false;
                    playerUP_destroyBedBreakUp = false;
                    playerUP_bedAttack = false;
                    playerUP_bedLvl = 1;
                    RandInt_GetBaseOrMiddle = 0;
                    playerUP_bedState = 200;
                    playerMain_bedState = 200;
                    playerUP_bedBar = 60;
                    playerMain_bedBar = 60;
                    spawnWood = false;
                    spawnStone = false;
                    spawnSmaragd_1 = false;
                    spawnSmaragd_2 = false;
                    spawnSmaragd_3 = false;
                    spawnSmaragd_4 = false;
                    loop_wood = 0;
                    loop_stone = 0;
                    loopSmaragd_1 = 0;
                    loopSmaragd_2 = 0;
                    loopSmaragd_3 = 0;
                    loopSmaragd_4 = 0;
                    woodCounter = 0;
                    stoneCounter = 0;
                    smaragdCounter_1 = 0;
                    smaragdCounter_2 = 0;
                    smaragdCounter_3 = 0;
                    smaragdCounter_4 = 0;
                    woodCounter_inv = 100;
                    stoneCounter_inv = 100;
                    leatherCounter_inv = 100;
                    smaragdCounter_inv = 100;
                    activateShop = false;
                    speedPosionCount = 0;
                    activateSpeedPoision = false;
                    speedBoostApplied = false;
                    drawSpeedPoision = false;
                    leathersSet_1 = false;
                    leathersSet_2 = false;
                    leathersSet_3 = false;
                    leathersSet_4 = false;
                    leathersSet_5 = false;
                    leathersSet_6 = false;
                    leathersSet_7 = false;
                    leathersSet_8 = false;
                    leathersSet_9 = false;
                    leathersSet_10 = false;
                    leathersSet_11 = false;
                    leathersSet_12 = false;
                    leathersSet_13 = false;
                    PlayerUP_leathersSet_1 = false;
                    PlayerUP_leathersSet_2 = false;
                    PlayerUP_leathersSet_3 = false;
                    PlayerUP_leathersSet_4 = false;
                    PlayerUP_leathersSet_5 = false;
                    PlayerUP_leathersSet_6 = false;
                    PlayerUP_leathersSet_7 = false;
                    PlayerUP_leathersSet_8 = false;
                    PlayerUP_leathersSet_9 = false;
                    PlayerUP_leathersSet_10 = false;
                    PlayerUP_leathersSet_11 = false;
                    PlayerUP_leathersSet_12 = false;
                    PlayerUP_leathersSet_13 = false;
                    woodSpawnSpeed = 50;
                    stoneSpawnSpeed = 300;
                    smaragdSpawnSpeed = 500;               
                    BedLvlPlayerMain = 1;               
                    playerMove_Up = 0;
                    playerMove_Down = 0;
                    playerMove_Left = 0;
                    playerMove_Right = 0;
                    playerDircation_Up = false;
                    playerDircation_Down = true;
                    playerDircation_Left = false;
                    playerDircation_Right = false;
                }
            }
        }
        else {
            playerUP_GetLifeBar = false;
        }
        //Attack PlayerUP
        //Is player in range checker
        if ((player_x > map_x+mapPlayerUP_x+50) && (player_y > map_y+mapPlayerUP_y) &&
            (player_x < map_x+mapPlayerUP_x+200) && (player_y < map_y+mapPlayerUP_y+50)) {
            console.log("In range Right");
            mapPlayerUP_x += playerUP_speed;
            playerUP_MoveRightCount++;
            console.log("Steps Right: " + playerUP_MoveRightCount);
        }
        if ((player_x > map_x+mapPlayerUP_x-200) && (player_y > map_y+mapPlayerUP_y) &&
            (player_x < map_x+mapPlayerUP_x-50) && (player_y < map_y+mapPlayerUP_y+50)) {
            console.log("In range Left");
            mapPlayerUP_x -= playerUP_speed;
            playerUP_MoveLeftCount++;
            console.log("Steps Left: " + playerUP_MoveLeftCount);
        }
        if ((player_x > map_x+mapPlayerUP_x-100) && (player_y > map_y+mapPlayerUP_y-270) &&
            (player_x < map_x+mapPlayerUP_x+100) && (player_y < map_y+mapPlayerUP_y-60)) {
            console.log("In range UP");
            mapPlayerUP_y -= playerUP_speed;
            playerUP_MoveUpCount++;
            console.log("Steps UP: " + playerUP_MoveUpCount);
        }
        if ((player_x > map_x+mapPlayerUP_x-100) && (player_y > map_y+mapPlayerUP_y+50) &&
            (player_x < map_x+mapPlayerUP_x+100) && (player_y < map_y+mapPlayerUP_y+200)) {
            console.log("In range Down");
            mapPlayerUP_y += playerUP_speed;
            playerUP_MoveDownCount++;
            console.log("Steps Down: " + playerUP_MoveDownCount);
        }
        //Attack Main Player
        if ((player_x > map_x+mapPlayerUP_x-50) && (player_y > map_y+mapPlayerUP_y-170) &&
            (player_x < map_x+mapPlayerUP_x+50) && (player_y < map_y+mapPlayerUP_y+100)) {
            player_speed = 0;
            PlayerUpAttack();
            PlayerUpDie();
        }
        else {
            player_speed = 3;
        }


        //SFX
        SFX_Directions();
        //Background music
        if (startGame) {
            backgroundMusicSound.play();
        }
    }

    // Function to render the scene
    function render() {
        // Clear canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        //Draw Game Menu
        if (startGame == false) {
            ctx.drawImage(gameMenu_main, 0,0);
            ctx.font = "60px Arial";
            if (WonGame) {
                ctx.fillStyle ="Green";
                ctx.fillText("Won", 650, 350);
            }
            else if (LoseGame) {
                ctx.fillStyle ="Red";
                ctx.fillText("Lose", 650, 350);
            }
            if (startSettings) {
                ctx.drawImage(settingScreen, 0,0);
                ctx.fillStyle ="White";
                ctx.font = "10px, Arial";
                ctx.fillText("Footstep sound:", 20,140);
                ctx.fillStyle ="Black";
                ctx.fillRect(768,88, 50,50);
                ctx.fillStyle ="White";
                ctx.fillRect(770,90, 50,50);
                ctx.fillStyle ="Black";
                ctx.fillText("+", 777,140);
                ctx.fillStyle ="Black";
                ctx.fillRect(768-70,88, 50,50);
                ctx.fillStyle ="White";
                ctx.fillRect(770-70,90, 50,50);
                ctx.fillStyle ="Black";
                ctx.fillText("-", 713,133);
                ctx.fillStyle ="White";
                ctx.fillText(FootstepsVolume*100 + "%", 560,140);
                ctx.fillText("UI sound:", 20,240);
                ctx.fillStyle ="Black";
                ctx.fillRect(768,188, 50,50);
                ctx.fillStyle ="White";
                ctx.fillRect(770,190, 50,50);
                ctx.fillStyle ="Black";
                ctx.fillText("+", 777,240);
                ctx.fillStyle ="Black";
                ctx.fillRect(768-70,188, 50,50);
                ctx.fillStyle ="White";
                ctx.fillRect(770-70,190, 50,50);
                ctx.fillStyle ="Black";
                ctx.fillText("-", 713,233);
                ctx.fillStyle ="White";
                ctx.fillText(UI_volume*100 + "%", 560,240);
                ctx.fillText("Baground Music:", 20,340);
                ctx.fillStyle ="Black";
                ctx.fillRect(768,288, 50,50);
                ctx.fillStyle ="White";
                ctx.fillRect(770,290, 50,50);
                ctx.fillStyle ="Black";
                ctx.fillText("+", 777,340);
                ctx.fillStyle ="Black";
                ctx.fillRect(768-70,288, 50,50);
                ctx.fillStyle ="White";
                ctx.fillRect(770-70,290, 50,50);
                ctx.fillStyle ="Black";
                ctx.fillText("-", 713,333);
                ctx.fillStyle ="White";
                ctx.fillText(backgroundMusicVolume*100 + "%", 560,340);
            }
            if (startCredits) {
                ctx.drawImage(creditsScreen, 0,0);
            }
        }

        if (startGame) {
            // Draw the map
            ctx.drawImage(layer_wather, map_x+waterMove_x, map_y, canvas.width*zoom, canvas.height*zoom*2);
            ctx.drawImage(layer_platform, map_x,  map_y, canvas.width*zoom, canvas.height*zoom*2);
            ctx.drawImage(layer_island, map_x, map_y, canvas.width*zoom, canvas.height*zoom*2);
            ctx.drawImage(layer_sea, map_x, map_y, canvas.width*zoom, canvas.height*zoom*2);
            ctx.drawImage(layer_seaBorder, map_x, map_y, canvas.width*zoom, canvas.height*zoom*2);
            ctx.drawImage(layer_bed, map_x, map_y, canvas.width*zoom, canvas.height*zoom*2);
            ctx.drawImage(layer_spawner, map_x, map_y, canvas.width*zoom, canvas.height*zoom*2);
            ctx.drawImage(layer_shop, map_x, map_y, canvas.width*zoom, canvas.height*zoom*2);
            ctx.drawImage(layer_IslandWay, map_x, map_y, canvas.width*zoom, canvas.height*zoom*2);
            ctx.drawImage(layer_islandSpawner, map_x, map_y, canvas.width*zoom, canvas.height*zoom*2);
            ctx.drawImage(layer_bridge, map_x, map_y, canvas.width*zoom, canvas.height*zoom*2)

            //Draw Items
            //-Wood
            if (spawnWood) {
                ctx.drawImage(item_wood, map_x+2810, map_y+4550);
                ctx.drawImage(item_count,map_x+2820, map_y+4550);
                ctx.fillStyle ="Black";
                ctx.font = "45px, Arial";
                ctx.fillText(woodCounter, map_x+2821,map_y+4560);
            }
            //-Stone
            if (spawnStone) {
                ctx.drawImage(item_stone, map_x+2200, map_y+4080);
                ctx.drawImage(item_count, map_x+2210, map_y+4080);
                ctx.fillStyle ="Black";
                ctx.font = "45px, Arial";
                ctx.fillText(stoneCounter, map_x+2211,map_y+4090);
            }
            //-Smaragd
            if (spawnSmaragd_1) {
                ctx.drawImage(item_smaragd, map_x+2220,map_y+2590);
                ctx.drawImage(item_count, map_x+2230, map_y+2590);
                ctx.fillStyle ="Black";
                ctx.font = "45px, Arial";
                ctx.fillText(smaragdCounter_1, map_x+2231,map_y+2600);
            }
            if (spawnSmaragd_2) {
                ctx.drawImage(item_smaragd, map_x+2220,map_y+2100);
                ctx.drawImage(item_count, map_x+2230, map_y+2090);
                ctx.fillStyle ="Black";
                ctx.font = "45px, Arial";
                ctx.fillText(smaragdCounter_2, map_x+2231,map_y+2100);
            }
            if (spawnSmaragd_3) {
                ctx.drawImage(item_smaragd, map_x+2800,map_y+2590);
                ctx.drawImage(item_count, map_x+2810, map_y+2580);
                ctx.fillStyle ="Black";
                ctx.font = "45px, Arial";
                ctx.fillText(smaragdCounter_3, map_x+2811,map_y+2590);
            }
            if (spawnSmaragd_4) {
                ctx.drawImage(item_smaragd, map_x+2800,map_y+2120);
                ctx.drawImage(item_count, map_x+2810, map_y+2110);
                ctx.fillStyle ="Black";
                ctx.font = "45px, Arial";
                ctx.fillText(smaragdCounter_4, map_x+2811,map_y+2120);
            }

            //Draw leathers
            if (leathersSet_1) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+3821, 80,100);
            }
            if (leathersSet_2) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+3821-100, 80,100);
            }
            if (leathersSet_3) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+3821-100*2, 80,100);
            }
            if (leathersSet_4) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+3821-100*3, 80,100);
            }
            if (leathersSet_5) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+3821-100*4, 80,100);
            }
            if (leathersSet_6) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+3821-100*5, 80,100);
            }
            if (leathersSet_7) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+3821-100*6, 80,100);
            }
            if (leathersSet_8) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+3821-100*7, 80,100);
            }
            if (leathersSet_9) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+3821-100*8, 80,100);
            }
            if (leathersSet_10) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+3821-100*9, 80,100);
            }
            if (leathersSet_11) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+3821-100*10, 80,100);
            }
            if (leathersSet_12) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+3821-100*11, 80,100);
            }
            if (leathersSet_13) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+3821-100*12+50, 80,50);
            }

            //Draw Leathers UP Player
            if (PlayerUP_leathersSet_1) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+720, 80,100);
            }
            if (PlayerUP_leathersSet_2) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+720+100, 80,100);
            }
            if (PlayerUP_leathersSet_3) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+720+100*2, 80,100);
            }
            if (PlayerUP_leathersSet_4) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+720+100*3, 80,100);
            }
            if (PlayerUP_leathersSet_5) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+720+100*4, 80,100);
            }
            if (PlayerUP_leathersSet_6) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+720+100*5, 80,100);
            }
            if (PlayerUP_leathersSet_7) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+720+100*6, 80,100);
            }
            if (PlayerUP_leathersSet_8) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+720+100*7, 80,100);
            }
            if (PlayerUP_leathersSet_9) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+720+100*8, 80,100);
            }
            if (PlayerUP_leathersSet_10) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+720+100*9, 80,100);
            }
            if (PlayerUP_leathersSet_11) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+720+100*10, 80,100);
            }
            if (PlayerUP_leathersSet_12) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+720+100*11, 80,100);
            }
            if (PlayerUP_leathersSet_13) {
                ctx.drawImage(leather_forward, map_x+2490,map_y+720+100*12, 80,50);
            }


            //Draw Main Player
            //Front
            if (playerDircation_Down) {
                if (targetFPS === 0) {
                    ctx.drawImage(playerWalkFront_4, player_x, player_y);
                } else if (playerMove_Down >= targetFPS * 0.75) {
                    ctx.drawImage(playerWalkFront_3, player_x, player_y);
                } else if (playerMove_Down >= targetFPS * 0.5) {
                    ctx.drawImage(playerWalkFront_2, player_x, player_y);
                } else if (playerMove_Down >= targetFPS * 0.25) {
                    ctx.drawImage(playerWalkFront_1, player_x, player_y);
                } else {
                    ctx.drawImage(playerWalkFront_4, player_x, player_y); // Default frame
                }
            }
            //Behind
            if (playerDircation_Up) {
                if (playerMove_Up >= targetFPS * 0.75) {
                    ctx.drawImage(playerWalkBack_3, player_x, player_y, character_size, character_size);
                } else if (playerMove_Up >= targetFPS * 0.5) {
                    ctx.drawImage(playerWalkBack_2, player_x, player_y, character_size, character_size);
                } else if (playerMove_Up >= targetFPS * 0.25) {
                    ctx.drawImage(playerWalkBack_1, player_x, player_y, character_size, character_size);
                } else {
                    ctx.drawImage(playerWalkBack_4, player_x, player_y, character_size, character_size); // Default frame
                }
            }
            //Left
            if (playerDircation_Left) {
                if (playerMove_Left >= targetFPS * 0.75) {
                    ctx.drawImage(playerWalkLeft_3, player_x, player_y, character_size, character_size);
                } else if (playerMove_Left >= targetFPS * 0.5) {
                    ctx.drawImage(playerWalkLeft_2, player_x, player_y, character_size, character_size);
                } else if (playerMove_Left >= targetFPS * 0.25) {
                    ctx.drawImage(playerWalkLeft_1, player_x, player_y, character_size, character_size);
                } else {
                    ctx.drawImage(playerWalkLeft_4, player_x, player_y, character_size, character_size); // Default frame
                }
            }
            //Right
            if (playerDircation_Right) {
                if (playerMove_Right >= targetFPS * 0.75) {
                    ctx.drawImage(playerWalkRight_3, player_x, player_y, character_size, character_size);
                } else if (playerMove_Right >= targetFPS * 0.5) {
                    ctx.drawImage(playerWalkRight_2, player_x, player_y, character_size, character_size);
                } else if (playerMove_Right >= targetFPS * 0.25) {
                    ctx.drawImage(playerWalkRight_1, player_x, player_y, character_size, character_size);
                } else {
                    ctx.drawImage(playerWalkRight_4, player_x, player_y, character_size, character_size); // Default frame
                }
            }
            //Draw Player 2
            
            //Draw Player 3
            //ctx.drawImage(player3WalkDown_1, map_x+180,map_y+2250, character_size,character_size);

            //Draw Player 4
            if (playerUP_diractionDown) {
                if (playerUpMove_Down >= targetFPS * 0.75) {
                    ctx.drawImage(player4WalkDown_1, map_x+mapPlayerUP_x,map_y+mapPlayerUP_y, character_size,character_size);
                }
                else if (playerUpMove_Down >= targetFPS * 0.5) {
                    ctx.drawImage(player4WalkDown_2, map_x+mapPlayerUP_x,map_y+mapPlayerUP_y, character_size,character_size);
                }
                else if (playerUpMove_Down >= targetFPS * 0.25) {
                    ctx.drawImage(player4WalkDown_3, map_x+mapPlayerUP_x,map_y+mapPlayerUP_y, character_size,character_size);
                }
                else {
                    ctx.drawImage(player4WalkDown_4, map_x+mapPlayerUP_x,map_y+mapPlayerUP_y, character_size,character_size);
                }
            }
            if (playerUP_diractionUp) {
                if (playerUpMove_Up >= targetFPS * 0.75) {
                    ctx.drawImage(player4WalkUp_1, map_x+mapPlayerUP_x,map_y+mapPlayerUP_y, character_size,character_size);
                }
                else if (playerUpMove_Up >= targetFPS * 0.5) {
                    ctx.drawImage(player4WalkUp_2, map_x+mapPlayerUP_x,map_y+mapPlayerUP_y, character_size,character_size);
                }
                else if (playerUpMove_Up >= targetFPS * 0.25) {
                    ctx.drawImage(player4WalkUp_3, map_x+mapPlayerUP_x,map_y+mapPlayerUP_y, character_size,character_size);
                }
                else {
                    ctx.drawImage(player4WalkUp_4, map_x+mapPlayerUP_x,map_y+mapPlayerUP_y, character_size,character_size);
                }
            }
            if (playerUP_diractionLeft) {
                if (playerUpMove_Left >= targetFPS * 0.75) {
                    ctx.drawImage(player4WalkLeft_1, map_x+mapPlayerUP_x,map_y+mapPlayerUP_y, character_size,character_size);
                }
                else if (playerUpMove_Left >= targetFPS * 0.5) {
                    ctx.drawImage(player4WalkLeft_2, map_x+mapPlayerUP_x,map_y+mapPlayerUP_y, character_size,character_size);
                }
                else if (playerUpMove_Left >= targetFPS * 0.25) {
                    ctx.drawImage(player4WalkLeft_3, map_x+mapPlayerUP_x,map_y+mapPlayerUP_y, character_size,character_size);
                }
                else {
                    ctx.drawImage(player4WalkLeft_4, map_x+mapPlayerUP_x,map_y+mapPlayerUP_y, character_size,character_size);
                }
            }
            if (playerUP_diractionRight) {
                if (playerUpMove_Right >= targetFPS * 0.75) {
                    ctx.drawImage(player4WalkRight_1, map_x+mapPlayerUP_x,map_y+mapPlayerUP_y, character_size,character_size);
                }
                else if (playerUpMove_Right >= targetFPS * 0.5) {
                    ctx.drawImage(player4WalkRight_2, map_x+mapPlayerUP_x,map_y+mapPlayerUP_y, character_size,character_size);
                }
                else if (playerUpMove_Right >= targetFPS * 0.25) {
                    ctx.drawImage(player4WalkRight_3, map_x+mapPlayerUP_x,map_y+mapPlayerUP_y, character_size,character_size);
                }
                else {
                    ctx.drawImage(player4WalkRight_4, map_x+mapPlayerUP_x,map_y+mapPlayerUP_y, character_size,character_size);
                }
            }
            //ctx.drawImage(player4WalkDown_1, map_x+mapPlayerUP_x,map_y+mapPlayerUP_y, character_size,character_size);

            //Draw Trees
            ctx.drawImage(layer_tree, map_x, map_y, canvas.width*zoom, canvas.height*zoom*2);

            //Bed level bar
            //Bed base down (Main)
            ctx.fillStyle = ("white");
            ctx.fillRect(map_x+2490,map_y+4505, playerMain_bedBar,3);
            ctx.fillStyle = ("black");
            ctx.font = '14px Arial'
            ctx.fillText("Lvl: " + BedLvlPlayerMain, map_x+2505,map_y+4500);
            //Bed base up
            ctx.fillStyle = ("white");
            ctx.fillRect(map_x+2485,map_y+70, playerUP_bedBar,3);
            ctx.fillStyle = ("black");
            ctx.font = '14px Arial'
            ctx.fillText("Lvl: " + playerUP_bedLvl, map_x+2498,map_y+65);
            //Bed base left
            ctx.fillStyle = ("white");
            ctx.fillRect(map_x+125,map_y+2305, 60,3);
            //Bed base right
            ctx.fillStyle = ("white");
            ctx.fillRect(map_x+4890,map_y+2315, 60,3);

            //Player up level bar
            ctx.fillStyle = ("white");
            if (playerUP_GetLifeBar) {
                ctx.fillRect(map_x+mapPlayerUP_x+20,map_y+mapPlayerUP_y+45, playerUP_LifeBar,3);
            }

            //GUI
            //-Draw Controller
            if (activateShop == false) {
                ctx.drawImage(mobileController_default, 10,canvas.height-180-10, 180,180);
            }
            //-Draw break button
            ctx.drawImage(breakButton, 10,10);
            //-Draw Items
            ctx.drawImage(item_wood, 800,50);
            ctx.font = "20px Arial";
            ctx.fillStyle = "Black";
            ctx.fillText(woodCounter_inv,770,75);
            ctx.drawImage(item_stone, 800,100);
            ctx.fillText(stoneCounter_inv,770,120);
            ctx.drawImage(item_smaragd, 800,150, 30,25);
            ctx.fillText((smaragdCounter_inv), 770,170);
            //-Draw Hearts
            //--1
            ctx.drawImage(empty_heart, 800,10, 30,25);
            if ((playerMain_LifePoints > 8.5) && playerMain_LifePoints < 9.5) {
                ctx.drawImage(half_heart, 800,10, 30,25);
            }
            if (playerMain_LifePoints >= 9.5) {
                ctx.drawImage(full_heart, 800,10, 30,25);
            }
            //--2
            ctx.drawImage(empty_heart, 760,10, 30,25);
            if ((playerMain_LifePoints > 7) && playerMain_LifePoints < 8.5) {
                ctx.drawImage(half_heart, 760,10, 30,25);
            }
            if (playerMain_LifePoints >= 8.5) {
                ctx.drawImage(full_heart, 760,10, 30,25);
            }
            //--3
            ctx.drawImage(empty_heart, 720,10, 30,25);
            if ((playerMain_LifePoints > 5) && playerMain_LifePoints < 6.5) {
                ctx.drawImage(half_heart, 720,10, 30,25);
            }
            if (playerMain_LifePoints >= 6.5) {
                ctx.drawImage(full_heart, 720,10, 30,25);
            }
            //--4
            ctx.drawImage(empty_heart, 680,10, 30,25);
            if ((playerMain_LifePoints > 3) && playerMain_LifePoints < 4.5) {
                ctx.drawImage(half_heart, 680,10, 30,25);
            }
            if (playerMain_LifePoints >= 4.5) {
                ctx.drawImage(full_heart, 680,10, 30,25);
            }
            //--5
            ctx.drawImage(empty_heart, 640,10, 30,25);
            if ((playerMain_LifePoints > 0.1) && playerMain_LifePoints < 2.5) {
                ctx.drawImage(half_heart, 640,10, 30,25);
            }
            if (playerMain_LifePoints >= 2.5) {
                ctx.drawImage(full_heart, 640,10, 30,25);
            }
            //-Leather Icon
            ctx.drawImage(leatherIcon, 800,200, 30,25);
            ctx.fillText(leatherCounter_inv,770,220);
            //-Draw Speed Posion
            if (drawSpeedPoision) {
                ctx.drawImage(speedPoitionIcon, 770,320, 60,60);
                ctx.fillStyle = "white";
                ctx.fillRect(765,315, 70,0.5);
                ctx.fillRect(765,315, 0.5,70);
                ctx.fillRect(765,385, 70,0.5);
                ctx.fillRect(835,315, 0.5,70);
            }
            if ((player_x > map_x+mapPlayerUP_x-70) && (player_y > map_y+mapPlayerUP_y-70) &&
            (player_x < map_x+mapPlayerUP_x+80) && (player_y < map_y+mapPlayerUP_y+80)) {
                ctx.fillStyle = "grey";
                ctx.fillRect(720,330, 110,50);
                ctx.fillStyle = "white";
                ctx.fillText("Attack", 750,360);
            }

            //Draw Shop
            if (activateShop) {
                ctx.drawImage(shop_img, 80,0, 681,391);
                //Draw Leather
                ctx.drawImage(leatherIcon, 175,95, 50,50);
                ctx.drawImage(item_wood, 450,95, 50,50);
                ctx.fillStyle ="White";
                ctx.font = "bold 30px Arial";
                ctx.fillText(woodPrice + " pcs", 520,132);
                //Draw Speed Poision
                //ctx.drawImage(speedPoitionIcon, 175,180, 50,50);
                //ctx.drawImage(item_stone, 450,180, 50,50);
                //ctx.fillStyle ="White";
                //ctx.font = "bold 30px Arial";
                //ctx.fillText(stonePrice + " pcs", 520,215);
                //Bed Protection
                ctx.drawImage(bedIcon, 185,270, 30,50);
                ctx.drawImage(item_smaragd, 450,270, 50,50);
                ctx.fillStyle ="White";
                ctx.font = "bold 30px Arial";
                ctx.fillText(emeraldPrice + " pcs", 520,305);
            }
        }

    };

    // Function to handle game loop
    function gameLoop() {
        update(); // Update game state
        render(); // Render the scene
        // Request next frame
        setTimeout(gameLoop, frameInterval);
        loop_wood++;
        loop_stone++;
        loopSmaragd_1++;
        waterMove_x += 0.5;
        if (waterMove_x == 300) {
            waterMove_x = 0;
        }
        if (!playerUP_break) {
            playerUP_count++;
        }
        if (loopSmaragd_1 == 100); {
            loopSmaragd_2++;
        }
        if (loopSmaragd_1 == 200); {
            loopSmaragd_3++;
        }
        if (loopSmaragd_1 == 300); {
            loopSmaragd_4++;
        }
        if (activateSpeedPoision) {
            speedPosionCount++;
        }
    }

    // Initial size adjustment on page load
    

    // Start the game loop
    gameLoop();

    // Add event listener for window resize
    window.addEventListener("resize", resizeCanvas);

    canvas.addEventListener('click', function(event) {
        const rect = canvas.getBoundingClientRect();
        const x = event.clientX - rect.left;
        const y = event.clientY - rect.top;
        console.log(`Mouse clicked at: x=${x}, y=${y}`);
        if (startGame) {
            if ((x >= 10) && (y >= 10) &&
                (x <= 60) && (y <= 60)) {
                    console.log("BREAK!");
                    startGame = false;
                    ButtonPressed.play();
            }
            //if ((x >= 770) && (y >= 320) &&
            //    (x <= 830) && (y <= 380)) {
            //    activateSpeedPoision = true;
            //    drawSpeedPoision = false;
            //}
            if ((player_x > map_x+mapPlayerUP_x-70) && (player_y > map_y+mapPlayerUP_y-70) &&
                (player_x < map_x+mapPlayerUP_x+80) && (player_y < map_y+mapPlayerUP_y+80)) {
                if ((x >= 720) && (y >= 330)) {
                    playerUP_attackPressed = true;
                }
            }
        }
        if (startGame && activateShop) {
            if ((x >= 670) && (y >= 70) &&
                ((x <= 740) && (y <= 120))) {
                activateShop = false;
                ButtonPressed.play();
            }
            if ((x >= 160) && (y >= 80) &&
                (x <= 240) && (y <= 160)) {
                    if (woodCounter_inv >= woodPrice) {
                        woodCounter_inv -= woodPrice;
                        leatherCounter_inv++;
                        buyItem.play();
                    }
                    else {
                        console.log("Not enough money");
                        errorSound.play();
                    }
            }
            if ((x >= 160) && (y >= 170) &&
                (x <= 240) && (y <= 250)) {
                console.log("Placeholder");
            }
            if ((x >= 160) && (y >= 260) &&
                (x <= 240) && (y <= 340)) {
                console.log("Buy BedProtection");
                if (smaragdCounter_inv >= emeraldPrice) {
                    smaragdCounter_inv -= emeraldPrice;
                    BedLvlPlayerMain++;
                    playerMain_bedState += 200;
                    console.log(playerMain_bedState);
                    playerMain_bedBar = 60;
                    buyItem.play();
                }
                else {
                    console.log("Not enough money");
                    errorSound.play();
                }
            }
        }
        if (startGame == false) {
            if ((x >= 340) && (y >= 200) &&
                (x <= 550 && (y <= 250))) {
                console.log("Start Game");
                ButtonPressed.play();
                startGame = true;
            }
            if ((x >= 340) && (y >= 260) &&
                (x <= 550 && (y <= 320))) {
                console.log("Start Settings");
                ButtonPressed.play();
                startSettings = true;
            }
            if ((x >= 340) && (y >= 330) &&
                (x <= 550 && (y <= 380))) {
                console.log("Start Credits");
                ButtonPressed.play();
                startCredits = true;
            }
        }
        if (startSettings) {
            if ((x >= 770) && (y >= 15) &&
                (x <= 825) && (y <= 60))
            startSettings = false;
            ButtonPressed.play();
            if ((x >= 700) && (y >= 90) &&
                (x <= 750) && (y <= 140)) {
                console.log("Change Footstep -");
                FootstepsVolume -= 0.05;
                ButtonPressed.play();
            }
            if ((x >= 770) && (y >= 90) &&
                (x <= 820) && (y <= 140)) {
                console.log("Change Footstep +");
                FootstepsVolume += 0.05;
                ButtonPressed.play();
            }
            if ((x >= 700) && (y >= 190) &&
                (x <= 750) && (y <= 250)) {
                console.log("Change UI -");
                UI_volume -= 0.05;
                ButtonPressed.play();
            }
            if ((x >= 770) && (y >= 190) &&
                (x <= 820) && (y <= 250)) {
                console.log("Change UI +");
                UI_volume += 0.05;
                ButtonPressed.play();
            }
            if ((x >= 700) && (y >= 290) &&
                (x <= 750) && (y <= 340)) {
                console.log("Change BG MUSIC -");
                backgroundMusicVolume -= 0.05;
                ButtonPressed.play();
            }
            if ((x >= 770) && (y >= 290) &&
                (x <= 820) && (y <= 340)) {
                console.log("Change BG MUSIC +");
                backgroundMusicVolume += 0.05;
                ButtonPressed.play();
            }
        }
        if (startCredits) {
            if ((x >= 770) && (y >= 15) &&
                (x <= 825) && (y <= 60))
            startCredits = false;
            ButtonPressed.play();
        }
    });

    function ItemSpawnLogic() {
        //console.log(loop_wood);
        if (loop_wood == woodSpawnSpeed) {
            loop_wood = 0;
            //console.log("WOOD ITEM DROP")
            spawnWood = true;
            woodCounter++;
            playerUpWoodCounter_inv++;
        }
        //console.log(loop_stone);
        if (loop_stone == stoneSpawnSpeed) {
            loop_stone = 0;
            //console.log("STONE ITEM DROP")
            spawnStone = true;
            stoneCounter++;
            playerUpStoneCounter_inv++;
        }
        if (loopSmaragd_1 == smaragdSpawnSpeed) {
            loopSmaragd_1 = 0;
            spawnSmaragd_1 = true;
            smaragdCounter_1++;
        }
        if (loopSmaragd_2 == smaragdSpawnSpeed*2) {
            loopSmaragd_2 = 0;
            spawnSmaragd_2 = true;
            smaragdCounter_2++;
        }
        if (loopSmaragd_3 == smaragdSpawnSpeed*3) {
            loopSmaragd_3 = 0;
            spawnSmaragd_3 = true;
            smaragdCounter_3++;
        }
        if (loopSmaragd_4 == smaragdSpawnSpeed*4) {
            loopSmaragd_4 = 0;
            spawnSmaragd_4 = true;
            smaragdCounter_4++;
        }
        //GetItem
        //STONE
        if ((map_y+3990 <= player_y) && (map_x+2190 >= player_x) &&
            (map_y+4040 >= player_y) && (map_x+2150 <= player_x)) {
            //console.log("Take stone");
            spawnStone = false;
            stoneCounter_inv += stoneCounter;
            stoneCounter = 0;
            getItemSound.play();
        }
        //WOOD
        if ((map_y+4450 <= player_y) && (map_x+2810 >= player_x) &&
            (map_y+4510 >= player_y) && (map_x+2810-60 <= player_x) ) {
            //console.log("Take wood");
            spawnWood = false;
            woodCounter_inv += woodCounter;
            woodCounter = 0;
            getItemSound.play();
        }
        //Smaragd
        if ((map_y+2450 <= player_y) && (map_x+2230 >= player_x) &&
            (map_y+2550 >= player_y) && (map_x+2230-60 <= player_x)) {
            console.log("Take Smaragd 1");
            spawnSmaragd_1 = false;
            smaragdCounter_inv += smaragdCounter_1;
            smaragdCounter_1 = 0;
            getItemSound.play();
        }
        if ((map_y+2000 <= player_y) && (map_x+2230 >= player_x) &&
            (map_y+2050 >= player_y) && (map_x+2230-60 <= player_x)) {
            console.log("Take Smaragd 2");
            spawnSmaragd_2 = false;
            smaragdCounter_inv += smaragdCounter_2;
            smaragdCounter_2 = 0;
            getItemSound.play();
        }
        if ((map_y+2450 <= player_y) && (map_x+2790 >= player_x) &&
            (map_y+2550 >= player_y) && (map_x+2790-60 <= player_x)) {
            console.log("Take Smaragd 3");
            spawnSmaragd_3 = false;
            smaragdCounter_inv += smaragdCounter_3;
            smaragdCounter_3 = 0;
            getItemSound.play();
        }
        if ((map_y+2000 <= player_y) && (map_x+2790 >= player_x) &&
            (map_y+2050 >= player_y) && (map_x+2790-60 <= player_x)) {
            console.log("Take Smaragd 4");
            spawnSmaragd_4 = false;
            smaragdCounter_inv += smaragdCounter_4;
            smaragdCounter_4 = 0;
            getItemSound.play();
        }
    }
    function playerBorder() {
        //Player borders
        //BUTTOM ISLAND
        //LEFT 
        if ((map_x+2088 >= player_x) && (map_y+3820 <= player_y)) {
            player_x += 10;
        }
        //RIGHT
        if ((map_x+2910 <= player_x) && (map_y+3820 <= player_y)) {
            player_x -= 10;
        }
        //BUTTOM
        if ((map_y+4530 <= player_y) && (map_x+2088 <= player_x)) {
            player_y -= 10;
        }
        //TOP --LEFT
        if ((map_y+3820 >= player_y) && (map_x+2088 <= player_x) &&
            (map_y+3820-50 <= player_y) && (map_x+2088+380 >= player_x)) {
            player_y += 10;
        }
        //TOP --RIGHT
        if ((map_y+3820 >= player_y) && (map_x+2575 <= player_x) &&
            (map_y+3820-50 <= player_y) && (map_x+2575+380 >= player_x)) {
            player_y += 10;
        }
        //SEA
        //TOP
        if ((map_x+2350 <= player_x) && (map_y+4110 >= player_y) &&
            (map_x+2350+340 >= player_x) && (map_y+4110-50 <= player_y)) {
                player_y -= 10;
        }
        //BUTTOM
        if ((map_x+2350 <= player_x) && (map_y+4380 >= player_y) &&
            (map_x+2350+340 >= player_x) && (map_y+4380-50 <= player_y)) {
                player_y += 10;
        }
        //LEFT
        if ((map_x+2300 <= player_x) && (map_y+4080 <= player_y) &&
            (map_x+2300+50 >= player_x) && (map_y+4080+300 >= player_y)) {
                player_x -= 10;
        }
        //RIGHT
        if ((map_x+2670 >= player_x) && (map_y+4080 <= player_y) &&
            (map_x+2670-50 <= player_x) && (map_y+4080+300 >= player_y)) {
            player_x += 10;
        }
        //BED
        //TOP
        if ((map_x+2450 <= player_x) && (map_y+4405 <= player_y) &&
            (map_x+2450+50 >= player_x) && (map_y+4405+20 >= player_y)) {
            player_y -=10;
        }
        //BUTTOM
        if ((map_x+2450 <= player_x) && (map_y+4455 <= player_y) &&
            (map_x+2450+50 >= player_x) && (map_y+4455+20 >= player_y)) {
            player_y +=10;
        }
        //LEFT
        if ((map_x+2450 <= player_x) && (map_y+4420 <= player_y) &&
            (map_x+2450+20 >= player_x) && (map_y+4420+50 >= player_y)) {
            player_x -=10;
        }
        //RIGHT
        if ((map_x+2500 <= player_x) && (map_y+4420 <= player_y) &&
            (map_x+2500+20 >= player_x) && (map_y+4420+50 >= player_y)) {
            player_x +=10;
        }
        //STONE
        //TOP
        if ((map_y+3910 <= player_y) && (map_x+2150+70 >= player_x) &&
        (map_y+3910+20 >= player_y) && (map_x+2150 <= player_x)) {
            player_y -= 10;
        }
        //BUTTOM
        if ((map_y+3950 <= player_y) && (map_x+2150+70 >= player_x) &&
        (map_y+3950+20 >= player_y) && (map_x+2150 <= player_x)) {
            player_y += 10;
        }
        //LEFT
        if ((map_y+3910 <= player_y) && (map_x+2150+20 >= player_x) &&
        (map_y+3910+30 >= player_y) && (map_x+2150 <= player_x)) {
            player_x -= 10;
        }
        //RIGHT
        if ((map_y+3910 <= player_y) && (map_x+2190+40 >= player_x) &&
        (map_y+3910+30 >= player_y) && (map_x+2190 <= player_x)) {
            player_x += 10;
        }
        //WOOD
        //TOP
        if ((map_y+4360 <= player_y) && (map_x+2760+70 >= player_x) &&
        (map_y+4360+20 >= player_y) && (map_x+2760 <= player_x)) {
            player_y -= 10;
        }
        //BUTTOM
        if ((map_y+4420 <= player_y) && (map_x+2760+70 >= player_x) &&
        (map_y+4420+20 >= player_y) && (map_x+2760 <= player_x)) {
            player_y += 10;
        }
        //LEFT
        if ((map_y+4360 <= player_y) && (map_x+2760+30 >= player_x) &&
        (map_y+4360+70 >= player_y) && (map_x+2760 <= player_x)) {
            player_x -= 10;
        }
        //RIGHT
        if ((map_y+4360 <= player_y) && (map_x+2810+30 >= player_x) &&
        (map_y+4360+70 >= player_y) && (map_x+2810 <= player_x)) {
            player_x += 10;
        }
        //SHOP
        //UP
        if ((map_x+2770 <= player_x) && (map_y+4070 >= player_y) &&
            (map_x+2770+200 >= player_x) && (map_y+4070-30 <= player_y)) {
            player_y += 10;
        }
        //DOWN
        if ((map_x+2770 <= player_x) && (map_y+4020-100 <= player_y) &&
            (map_x+2770+200 >= player_x) && (map_y+4020+30 >= player_y)) {
            player_y -= 10;
        }
        //LEFT
        if ((map_x+2770 <= player_x) && (map_y+4070 >= player_y) &&
            (map_x+2770+50 >= player_x) && (map_y+4070-50 <= player_y)) {
            player_x -= 10;
        }
        //Leather Way Border
        //LEFT
        if ((map_x+2420 <= player_x) && (map_y+3820 >= player_y) &&
            (map_x+2420+50 >= player_x) && (map_y+3820-1250 <= player_y)) {
            player_x += 10;
        }
        //RIGHT
        if ((map_x+2520 <= player_x) && (map_y+3820 >= player_y) &&
            (map_x+2520+50 >= player_x) && (map_y+3820-1250 <= player_y)) {
            player_x -= 10;
        }

        //Middle
        //DOWN --LEFT
        if ((map_y+2570 <= player_y) && (map_x+2050 <= player_x) &&
            (map_y+2570+50 >= player_y) && (map_x+2088+380 >= player_x)) {
            player_y -= 10;
        }
        //DOWN --RIGHT
        if ((map_y+2570 <= player_y) && (map_x+2520 <= player_x) &&
            (map_y+2570+50 >= player_y) && (map_x+2520+420 >= player_x)) {
            player_y -= 10;
        }
        //LEFT --BUTTOM
        if ((map_x+2000 <= player_x) && (map_y+2250 <= player_y) &&
            (map_x+2050 >= player_x) && (map_y+2250+400 >= player_y)) {
            player_x += 10;
        }
        //LEFT --UP
        if ((map_x+2000 <= player_x) && (map_y+1850 <= player_y) &&
            (map_x+2050 >= player_x) && (map_y+2250+400 >= player_y)) {
            player_x += 10;
        }
        //LEFT
        if ((map_x+2000 <= player_x) && (map_y+1850 <= player_y) &&
            (map_x+2050 >= player_x) && (map_y+1850+350 >= player_y)) {
            player_x += 10;
        }
        //UP --LEFT
        if ((map_y+1800 <= player_y) && (map_x+2050 <= player_x) &&
            (map_y+1800+50 >= player_y) && (map_x+2088+370 >= player_x)) {
            player_y += 10;
        }
        //UP --RIGHT
        if ((map_y+1800 <= player_y) && (map_x+2520 <= player_x) &&
            (map_y+1800+50 >= player_y) && (map_x+2520+400 >= player_x)) {
            player_y += 10;
        }
        //UP
        //If player isn't middle
        if (!PlayerUP_leathersSet_13) {
            if ((map_y+1800 <= player_y) && (map_x+2050 <= player_x) &&
                (map_y+1800+50 >= player_y) && (map_x+2520+400 >= player_x)) {
                player_y += 10;
            }
        }
        //RIGHT --BUTTOM
        if ((map_x+2920 <= player_x) && (map_y+2260 <= player_y) &&
            (map_x+2920+50 >= player_x) && (map_y+2260+400 >= player_y)) {
            player_x -= 10;
        }
        //RIGHT --UP
        if ((map_x+2920 <= player_x) && (map_y+1850 <= player_y) &&
            (map_x+2920+50 >= player_x) && (map_y+1850+340 >= player_y)) {
            player_x -= 10;
        }
        //RIGHT
        if ((map_x+2920 <= player_x) && (map_y+1850 <= player_y) &&
            (map_x+2920+50 >= player_x) && (map_y+2260+400 >= player_y)) {
            player_x -= 10;
        }
        //Spawner in the MIDDLE Border
        //UP --LEFT
        //--UP
        if ((map_y+1950 <= player_y) && (map_x+2150 <= player_x) &&
            (map_y+1950+40 >= player_y) && (map_x+2150+80 >= player_x)) {
            player_y -= 20;
        }
        //--DOWN
        if ((map_y+1960 <= player_y) && (map_x+2150 <= player_x) &&
            (map_y+1960+40 >= player_y) && (map_x+2150+80 >= player_x)) {
            player_y += 30;
        }
        //--LEFT
        if ((map_y+1950 <= player_y) && (map_x+2150 <= player_x) &&
            (map_y+1950+40 >= player_y) && (map_x+2150+40 >= player_x)) {
            player_x -= 10;
        }
        //--RIGHT
        if ((map_y+1950 <= player_y) && (map_x+2150-40 <= player_x) &&
            (map_y+1950+40 >= player_y) && (map_x+2150+40 >= player_x)) {
            player_x += 10;
        }
        //DOWN --LEFT
        //--UP
        if ((map_y+2420 <= player_y) && (map_x+2150 <= player_x) &&
            (map_y+2420+30 >= player_y) && (map_x+2150+80 >= player_x)) {
            player_y -= 10;
        }
        //--DOWN
        if ((map_y+2450 <= player_y) && (map_x+2150 <= player_x) &&
            (map_y+2450+40 >= player_y) && (map_x+2150+80 >= player_x)) {
            player_y += 10;
        }
        //--LEFT
        if ((map_y+2420 <= player_y) && (map_x+2150 <= player_x) &&
            (map_y+2490 >= player_y) && (map_x+2150+40 >= player_x)) {
            player_x -= 10;
        }
        //--RIGHT
        if ((map_y+2420 <= player_y) && (map_x+2150-40 <= player_x) &&
            (map_y+2490 >= player_y) && (map_x+2150+40 >= player_x)) {
            player_x += 10;
        }
        //UP --RIGHT
        //--UP
        if ((map_y+1950 <= player_y) && (map_x+2750 <= player_x) &&
            (map_y+1950+40 >= player_y) && (map_x+2750+80 >= player_x)) {
            player_y -= 20;
        }
        //--DOWN
        if ((map_y+1960 <= player_y) && (map_x+2750 <= player_x) &&
            (map_y+1960+40 >= player_y) && (map_x+2750+80 >= player_x)) {
            player_y += 30;
        }
        //--LEFT
        if ((map_y+1950 <= player_y) && (map_x+2750 <= player_x) &&
            (map_y+1950+40 >= player_y) && (map_x+2750+40 >= player_x)) {
            player_x -= 10;
        }
        //--RIGHT
        if ((map_y+1950 <= player_y) && (map_x+2750-40 <= player_x) &&
            (map_y+1950+40 >= player_y) && (map_x+2750+40 >= player_x)) {
            player_x += 10;
        }
        //UP --LEFT
        //--UP
        if ((map_y+2420 <= player_y) && (map_x+2750 <= player_x) &&
            (map_y+2490 >= player_y) && (map_x+2750+80 >= player_x)) {
            player_y -= 20;
        }
        //--DOWN
        if ((map_y+2420 <= player_y) && (map_x+2750 <= player_x) &&
            (map_y+2490 >= player_y) && (map_x+2750+80 >= player_x)) {
            player_y += 30;
        }
        //--LEFT
        if ((map_y+2420 <= player_y) && (map_x+2750 <= player_x) &&
            (map_y+2490 >= player_y) && (map_x+2750+40 >= player_x)) {
            player_x -= 10;
        }
        //--RIGHT
        if ((map_y+2420 <= player_y) && (map_x+2750-40 <= player_x) &&
            (map_y+2490 >= player_y) && (map_x+2750+40 >= player_x)) {
            player_x += 10;
        }

        //Leather way border up
        //--LEFT
        if ((map_x+2088+320 <= player_x) && (map_y+1850 >= player_y) &&
            (map_x+2088+320+50 >= player_x) && (map_y+1850-1250 <= player_y)) {
            player_x += 10;
        }
        //--RIGHT
        if ((map_x+2088+420 <= player_x) && (map_y+1850 >= player_y) &&
            (map_x+2088+420+50 >= player_x) && (map_y+1850-1250 <= player_y)) {
            player_x -= 10;
        }

        //UP BASE
        //DOWN --LEFT
        if ((map_y+620 <= player_y) && (map_x+2000 <= player_x) &&
            (map_y+620+50 >= player_y && (map_x+2000+450 >= player_x))) {
            player_y -= 10;
        }
        //DOWN --RIGHT
        if ((map_y+620 <= player_y) && (map_x+2450+80 <= player_x) &&
            (map_y+620+50 >= player_y && (map_x+2450+80+400 >= player_x))) {
            player_y -= 10;
        }
        //LEFT
        if ((map_y-100 <= player_y) && (map_x+1980 <= player_x) &&
            (map_y+620 >= player_y && (map_x+1980+50 >= player_x))) {
            player_x += 10;
        }
        //RIGHT
        if ((map_y-100 <= player_y) && (map_x+2900 <= player_x) &&
            (map_y+620 >= player_y && (map_x+2900+50 >= player_x))) {
            player_x -= 10;
        }
        //UP
        if ((map_y-100 >= player_y) && (map_x+1980 <= player_x) &&
            (map_y-150 <= player_y) && (map_x+2900+50 >= player_x)) {
            player_y += 10;
        }
        //SEA
        //--UP
        if ((map_y+150 <= player_y) && (map_x+1990+300 <= player_x) &&
            (map_y+150+50 >= player_y) && (map_x+1990+300*2+60 >= player_x)) {
            player_y -= 10;
        }
        //DOWN
        if ((map_y+410 <= player_y) && (map_x+1990+300 <= player_x) &&
            (map_y+410+50 >= player_y) && (map_x+1990+300*2+60 >= player_x)) {
            player_y += 10;
        }
        //LEFT
        if ((map_y+150 <= player_y) && (map_x+1990+300 <= player_x) &&
            (map_y+150+320 >= player_y) && (map_x+1990+300+50 >= player_x)) {
            player_x -= 10;
        }
        //RIGHT
        if ((map_y+150 <= player_y) && (map_x+1990+300*2 <= player_x) &&
            (map_y+150+320 >= player_y) && (map_x+1990+300*2+60 >= player_x)) {
            player_x += 10;
        }
        //BED
        //TOP
        if ((map_y-20 <= player_y) && (map_x+2440 <= player_x) &&
            (map_y >= player_y) && (map_x+2440+50 >= player_x)) {
            player_y -= 10;
        }
        //BUTTOM
        if ((map_y <= player_y) && (map_x+2440 <= player_x) &&
            (map_y+50 >= player_y) && (map_x+2440+50 >= player_x)) {
            player_y += 10;
        }
        //LEFT
        if ((map_y-20 <= player_y) && (map_x+2440 <= player_x) &&
            (map_y+50 >= player_y) && (map_x+2440+50 >= player_x)) {
            player_x -= 10;
        }
        //RIGHT
        if ((map_y-20 <= player_y) && (map_x+2450 <= player_x) &&
            (map_y+50 >= player_y) && (map_x+2450+50 >= player_x)) {
            player_x += 10;
        }
        //WOOD
        //UP
        if ((map_y+30 <= player_y) && (map_x+2120 <= player_x) &&
            (map_y+40 >= player_y) && (map_x+2120+70 >= player_x)) {
            player_y -= 20;
        }
        //DOWN
        if ((map_y+30 <= player_y) && (map_x+2120 <= player_x) &&
            (map_y+60 >= player_y) && (map_x+2120+70 >= player_x)) {
            player_y += 20;
        }
        //LEFT
        if ((map_y+30 <= player_y) && (map_x+2120 <= player_x) &&
            (map_y+70 >= player_y) && (map_x+2120+50 >= player_x)) {
            player_x -= 20;
        }
        //RIGHT
        if ((map_y+30 <= player_y) && (map_x+2120+20 <= player_x) &&
            (map_y+70 >= player_y) && (map_x+2120+70 >= player_x)) {
            player_x += 20;
        }
        //STONE
        //UP
        if ((map_y+480 <= player_y) && (map_x+1990+790 <= player_x) &&
            (map_y+480+30 >= player_y) && (map_x+1990+790+50 >= player_x)) {
            player_y -= 20;
        }
        //DOWN
        if ((map_y+490 <= player_y) && (map_x+1990+790 <= player_x) &&
            (map_y+490+30 >= player_y) && (map_x+1990+790+50 >= player_x)) {
            player_y += 20;
        }
        //LEFT
        if ((map_y+480 <= player_y) && (map_x+1990+790 <= player_x) &&
            (map_y+480+40 >= player_y) && (map_x+1990+790+50 >= player_x)) {
            player_x -= 20;
        }
        //RIGHT
        if ((map_y+480 <= player_y) && (map_x+1990+790+10 <= player_x) &&
            (map_y+480+40 >= player_y) && (map_x+1990+790+50 >= player_x)) {
            player_x += 20;
        }
        //SHOP
        //LEFT
        if ((map_y+400 <= player_y) && (map_x+2080 <= player_x) &&
            (map_y+400+90 >= player_y) && (map_x+2080+50 >= player_x)) {
            player_x -= 10;
        }
        //RIGHT
        if ((map_y+400 <= player_y) && (map_x+2100 <= player_x) &&
            (map_y+400+90 >= player_y) && (map_x+2080+160 >= player_x)) {
            player_x += 10;
        }
        //UP
        if ((map_y+400 <= player_y) && (map_x+2080 <= player_x) &&
            (map_y+400+50 >= player_y) && (map_x+2080+160 >= player_x)) {
            player_y -= 10;
        }
        //DOWN
        if ((map_y+490 <= player_y) && (map_x+2080 <= player_x) &&
            (map_y+490+50 >= player_y) && (map_x+2080+160 >= player_x)) {
            player_y += 50;
            activateShop = true;
        }

        //BASE LEFT
        //UP
        if ((map_y+1800 <= player_y) && (map_x-40 <= player_x) &&
            (map_y+1800+50 >= player_y) && (map_x-40+850 >= player_x)) {
            player_y += 10;
        }
        //DOWN
        if ((map_y+2570 <= player_y) && (map_x-40 <= player_x) &&
            (map_y+2570+50 >= player_y) && (map_x-40+850 >= player_x)) {
            player_y -= 10;
        }
        //LEFT
        if ((map_y+1800 <= player_y) && (map_x-90 <= player_x) &&
            (map_y+2750+50 >= player_y) && (map_x-40 >= player_x)) {
            player_x += 10;
        }
        //RIGHT --UP
        if ((map_y+1800 <= player_y) && (map_x+810 <= player_x) &&
            (map_y+1800+400 >= player_y) && (map_x+810+50 >= player_x)) {
            player_x -= 10;
        }
        //RIGHT --DOWN
        if ((map_y+2250 <= player_y) && (map_x+810 <= player_x) &&
            (map_y+2250+400 >= player_y) && (map_x+810+50 >= player_x)) {
            player_x -= 10;
        }
        //SEA
        //UP
        if ((map_y+2100 <= player_y) && (map_x+230 <= player_x) &&
            (map_y+2100+50 >= player_y) && (map_x+580 >= player_x)) {
            player_y -= 10;
        }
        //DOWN
        if ((map_y+2100+310-50 <= player_y) && (map_x+230 <= player_x) &&
            (map_y+2100+310 >= player_y) && (map_x+580 >= player_x)) {
            player_y += 10;
        }
        //LEFT
        if ((map_y+2100 <= player_y) && (map_x+220 <= player_x) &&
            (map_y+2410 >= player_y) && (map_x+270 >= player_x)) {
            player_x -= 10;
        }
        //RIGHT
        if ((map_y+2100 <= player_y) && (map_x+220+370-50 <= player_x) &&
            (map_y+2410 >= player_y) && (map_x+220+370 >= player_x)) {
            player_x += 10;
        }
        //WOOD
        //UP
        if ((map_y+2000-40 <= player_y) && (map_x+120 <= player_x) &&
            (map_y+2000 >= player_y) && (map_x+120+70 >= player_x)) {
            player_y -= 20;
        }
        //DOWN
        if ((map_y+2010-40 <= player_y) && (map_x+120 <= player_x) &&
            (map_y+2010 >= player_y) && (map_x+120+70 >= player_x)) {
            player_y += 20;
        }
        //LEFT
        if ((map_y+2000-40 <= player_y) && (map_x+120 <= player_x) &&
            (map_y+2000 >= player_y) && (map_x+120+40 >= player_x)) {
            player_x -= 20;
        }
        //RIGHT
        if ((map_y+2000-40 <= player_y) && (map_x+190-40 <= player_x) &&
            (map_y+2000 >= player_y) && (map_x+190 >= player_x)) {
            player_x += 20;
        }
        //BED
        //DOWN
        if ((map_y+2290-40 <= player_y) && (map_x+80 <= player_x) &&
            (map_y+2290 >= player_y) && (map_x+80+70 >= player_x)) {
            player_y += 20;
        }
        //UP
        if ((map_y+2240-40 <= player_y) && (map_x+80 <= player_x) &&
            (map_y+2240 >= player_y) && (map_x+80+70 >= player_x)) {
            player_y -= 20;
        }
        //LEFT
        if ((map_y+2290-40 <= player_y) && (map_x+80 <= player_x) &&
            (map_y+2290 >= player_y) && (map_x+80+40 >= player_x)) {
            player_x -= 20;
        }
        //RIGHT
        if ((map_y+2290-40 <= player_y) && (map_x+80+50-30 <= player_x) &&
            (map_y+2290 >= player_y) && (map_x+80+50 >= player_x)) {
            player_x += 20;
        }
        //STONE
        //UP
        if ((map_y+2480-30 <= player_y) && (map_x+220+490-50 <= player_x) &&
            (map_y+2480 >= player_y) && (map_x+220+490 >= player_x)) {
            player_y -= 20;
        }
        //DOWN
        if ((map_y+2510-30 <= player_y) && (map_x+220+490-50 <= player_x) &&
            (map_y+2510 >= player_y) && (map_x+220+490 >= player_x)) {
            player_y += 20;
        }
        //LEFT
        if ((map_y+2480-30 <= player_y) && (map_x+220+490-50 <= player_x) &&
            (map_y+2480 >= player_y) && (map_x+220+490 >= player_x)) {
            player_x -= 20;
        }
        //RIGHT
        if ((map_y+2480-30 <= player_y) && (map_x+220+510-50 <= player_x) &&
            (map_y+2480 >= player_y) && (map_x+220+510 >= player_x)) {
            player_x += 20;
        }
        //SHOP
        //UP
        if ((map_y+1950 <= player_y) && (map_x+650 <= player_x) &&
            (map_y+1950+50 >= player_y) && (map_x+900 >= player_x)) {
            player_y -= 10;
        }
        //DOWN
        if ((map_y+2030 <= player_y) && (map_x+650 <= player_x) &&
            (map_y+2030+50 >= player_y) && (map_x+900 >= player_x)) {
            activateShop = true;
            player_y += 50;
        }
        //LEFT
        if ((map_y+1950 <= player_y) && (map_x+650 <= player_x) &&
            (map_y+2030+50 >= player_y) && (map_x+900 >= player_x)) {
            player_x -= 10;
        }
        //BRIDGE BORDERS --LEFT
        //UP
        if ((map_y+2150 <= player_y) && (map_x+810 <= player_x) &&
            (map_y+2150+50 >= player_y) && (map_x+2050 >= player_x)) {
            player_y += 10;
        }
        //DOWN
        if ((map_y+2300-50 <= player_y) && (map_x+810 <= player_x) &&
            (map_y+2300 >= player_y) && (map_x+2050 >= player_x)) {
            player_y -= 10;
        }
        //BASE RIGHT
        //LEFT --UP
        if ((map_y+1850 <= player_y) && (map_x+4100 <= player_x) &&
            (map_y+2150 >= player_y) && (map_x+4150 >= player_x)) {
            player_x += 10;
        }
        //LEFT --DOWN
        if ((map_y+2300 <= player_y) && (map_x+4100 <= player_x) &&
            (map_y+2600 >= player_y) && (map_x+4150 >= player_x)) {
            player_x += 10;
        }
        //RIGHT
        if ((map_y+1800 <= player_y) && (map_x+5000 <= player_x) &&
            (map_y+2550+50 >= player_y) && (map_x+5030 >= player_x)) {
            player_x -= 10;
        }
        //UP
        if ((map_y+1800 <= player_y) && (map_x+4100 <= player_x) &&
            (map_y+1800+50 >= player_y) && (map_x+5000 >= player_x)) {
            player_y += 10;
        }
        //DOWN
        if ((map_y+2550 <= player_y) && (map_x+4100 <= player_x) &&
            (map_y+2550+50 >= player_y) && (map_x+5000 >= player_x)) {
            player_y -= 10;
        }
        //SEA
        //UP
        if ((map_y+2100 <= player_y) && (map_x+4400 <= player_x) &&
            (map_y+2100+50 >= player_y) && (map_x+4750 >= player_x)) {
            player_y -= 10;
        }
        //DOWN
        if ((map_y+2350 <= player_y) && (map_x+4400 <= player_x) &&
            (map_y+2350+50 >= player_y) && (map_x+4750 >= player_x)) {
            player_y += 10;
        }
        //LEFT
        if ((map_y+2100 <= player_y) && (map_x+4350 <= player_x) &&
            (map_y+2350+50 >= player_y) && (map_x+4450 >= player_x)) {
            player_x -= 10;
        }
        //RIGHT
        if ((map_y+2100 <= player_y) && (map_x+4700 <= player_x) &&
            (map_y+2350+50 >= player_y) && (map_x+4750 >= player_x)) {
            player_x += 10;
        }
        //STONE
        //UP
        if ((map_y+2450 <= player_y) && (map_x+4240 <= player_x) &&
            (map_y+2450+30 >= player_y) && (map_x+4300 >= player_x)) {
            player_y -= 20;
        }
        //DOWN
        if ((map_y+2480 <= player_y) && (map_x+4240 <= player_x) &&
            (map_y+2480+30 >= player_y) && (map_x+4300 >= player_x)) {
            player_y += 20;
        }
        //LEFT
        if ((map_y+2450 <= player_y) && (map_x+4240 <= player_x) &&
            (map_y+2450+30 >= player_y) && (map_x+4240+30 >= player_x)) {
            player_x -= 20;
        }
        //RIGHT
        if ((map_y+2450 <= player_y) && (map_x+4300-30 <= player_x) &&
            (map_y+2450+30 >= player_y) && (map_x+4300 >= player_x)) {
            player_x += 20;
        }
        //WOOD
        //UP
        if ((map_y+1990-40 <= player_y) && (map_x+4850 <= player_x) &&
            (map_y+1990 >= player_y) && (map_x+4850+50 >= player_x)) {
            player_y -= 20;
        }
        //DOWN
        if ((map_y+1990 <= player_y) && (map_x+4850 <= player_x) &&
            (map_y+1990+30 >= player_y) && (map_x+4850+50 >= player_x)) {
            player_y += 20;
        }
        //LEFT
        if ((map_y+1990-40 <= player_y) && (map_x+4850 <= player_x) &&
            (map_y+1990 >= player_y) && (map_x+4850+30 >= player_x)) {
            player_x -= 20;
        }
        //RIGHT
        if ((map_y+1990-40 <= player_y) && (map_x+4880 <= player_x) &&
            (map_y+1990 >= player_y) && (map_x+4910 >= player_x)) {
            player_x += 20;
        }
        //BED
        //UP
        if ((map_y+2250-40 <= player_y) && (map_x+4850 <= player_x) &&
            (map_y+2250 >= player_y) && (map_x+4850+50 >= player_x)) {
            player_y -= 20;
        }
        //DOWN
        if ((map_y+2250 <= player_y) && (map_x+4850 <= player_x) &&
            (map_y+2250+50 >= player_y) && (map_x+4850+50 >= player_x)) {
            player_y += 20;
        }
        //LEFT
        if ((map_y+2250-40 <= player_y) && (map_x+4850 <= player_x) &&
            (map_y+2250+50 >= player_y) && (map_x+4850+40 >= player_x)) {
            player_x -= 20;
        }
        //RIGHT
        if ((map_y+2250-40 <= player_y) && (map_x+4850 <= player_x) &&
            (map_y+2250+50 >= player_y) && (map_x+4890 >= player_x)) {
            player_x += 20;
        }
        //SHOP
        //UP
        if ((map_y+2000-100 <= player_y) && (map_x+4200 <= player_x) &&
            (map_y+2000+40-100 >= player_y) && (map_x+4350 >= player_x)) {
            player_y -= 20;
        }
        //DOWN
        if ((map_y+2000 <= player_y) && (map_x+4200 <= player_x) &&
            (map_y+2000+40 >= player_y) && (map_x+4350 >= player_x)) {
            player_y += 50;
            activateShop = true;
        }
        //LEFT
        if ((map_y+2000-100 <= player_y) && (map_x+4200 <= player_x) &&
            (map_y+2000+40 >= player_y) && (map_x+4250 >= player_x)) {
            player_x -= 20;
        }
        //RIGHT
        if ((map_y+2000-100 <= player_y) && (map_x+4350-50 <= player_x) &&
            (map_y+2000+40 >= player_y) && (map_x+4350 >= player_x)) {
            player_x += 20;
        }

        //BRIDGE BORDERS --RIGHT
        //UP
        if ((map_y+2150 <= player_y) && (map_x+2900 <= player_x) &&
            (map_y+2150+50 >= player_y) && (map_x+4150 >= player_x)) {
            player_y += 10;
        }
        //DOWN
        if ((map_y+2300-50 <= player_y) && (map_x+2900 <= player_x) &&
            (map_y+2300 >= player_y) && (map_x+4150 >= player_x)) {
            player_y -= 10;
        }
    }
    function PlayerUpAttack() {
        if (playerUP_gettingItemsMiddle) {
            playerUP_gettingItemsMiddleCheck = true;
            playerUP_gettingItemsMiddle = false;
        }
        if (playerUP_gettingBackBase) {
            playerUP_gettingBackBaseCheck = true;
            playerUP_gettingBackBase = false;
        }
        if (playerUP_gettingBackMiddle) {
            playerUP_gettingBackMiddleCheck = true;
            playerUP_gettingBackMiddle = false;
        }
        if (playerUP_gettingMainPlayerBase) {
            playerUP_gettingMainPlayerBaseCheck = true;
            playerUP_gettingMainPlayerBase = false;
        }
        if (playerUP_bedAttack) {
            playerUP_bedAttackCheck = true;
            playerUP_bedAttack = false;
        }
        if (playerUP_destroyBedBreakUp) {
            playerUP_destroyBedBreakUpCheck = true;
            playerUP_destroyBedBreakUp = false;
        }
        if (playerUP_gettingToMiddleEnd) {
            playerUP_gettingToMiddleEndCheck = true;
            playerUP_gettingToMiddleEnd = false;
        }
    }
    function PlayerUpDie() {
        playerUP_break = true;
        if (playerMain_LifePoints > 0) {
            playerMain_LifePoints -= 0.05;
            console.log("Player Main life: " + playerMain_LifePoints);
            demageSound.play();
        }
        if (playerMain_LifePoints < 0) {
            playerUP_break = false;
            deathSound.play();
            map_y = -3850;
            map_x = -2250;
            playerMain_LifePoints = 10;
            if (playerUP_MoveRightCount > 0) {
                mapPlayerUP_x -= playerUP_speed;
                playerUP_MoveRightCount--;
            }
            if (playerUP_MoveLeftCount > 0) {
                mapPlayerUP_x += playerUP_speed;
                playerUP_MoveLeftCount--;
            }
            if (playerUP_MoveUpCount > 0) {
                mapPlayerUP_y += playerUP_speed;
                playerUP_MoveUpCount--;
            }
            if (playerUP_MoveDownCount > 0) {
                mapPlayerUP_y -= playerUP_speed;
                playerUP_MoveDownCount--;
            }
            if (playerUP_gettingItemsMiddleCheck) {
                playerUP_gettingItemsMiddle = true;
                playerUP_gettingItemsMiddleCheck = false;
            }
            if (playerUP_gettingBackBaseCheck) {
                playerUP_gettingBackBase = true;
                playerUP_gettingBackBaseCheck = false;
            }
            if (playerUP_gettingBackMiddleCheck) {
                playerUP_gettingBackMiddle = true;
                playerUP_gettingBackMiddleCheck = false;
            }
            if (playerUP_gettingMainPlayerBaseCheck) {
                playerUP_gettingMainPlayerBase = true;
                playerUP_gettingMainPlayerBaseCheck = false;
            }
            if (playerUP_bedAttackCheck) {
                playerUP_bedAttack = true;
                playerUP_bedAttackCheck = false;
            }
            if (playerUP_destroyBedBreakUpCheck) {
                playerUP_destroyBedBreakUp = true;
                playerUP_destroyBedBreakUpCheck = false;
            }
            if (playerUP_gettingToMiddleEndCheck) {
                playerUP_gettingToMiddleEnd = true;
                playerUP_gettingToMiddleEndCheck = false;
            }

            if (BedLvlPlayerMain === 0) {
                startGame = false;
                console.log("Lose");
                LoseGame = true;
                //RESET
                map_x = -1900;
                map_y = -3900;
                mapPlayerUP_x = 2500;
                mapPlayerUP_y = 70;
                gettingBackCount = 0;
                playerUP_LifePoints = 10;
                playerMain_LifePoints = 10;
                playerUP_GetLifeBar = false;
                playerUP_LifeBar = 60;
                playerUP_attackPressed = false;
                player_x = 480;
                player_y = 120;
                player_speed = 3;
                playerUP_speed = 3;
                playerUP_count = 0;
                playerUpWoodCounter_inv = 0;
                playerUpStoneCounter_inv = 0;
                playerUpSmaragdCounter_inv = 0;
                playerUpActivateShop = false;
                playerUPleatherCounter_inv = 0;
                playerUP_countEnd = false;
                playerUP_giveLeathers = false;
                playerUP_gettingToMiddleEnd = false;
                playerUP_gettingItemsMiddle = false;
                playerUP_gettingBackBase = false;
                playerUP_gettingBackMiddle = false;
                playerUP_gettingMainPlayerBase = false;
                playerUP_destroyBedBreakUp = false;
                playerUP_bedAttack = false;
                playerUP_bedLvl = 1;
                RandInt_GetBaseOrMiddle = 0;
                playerUP_bedState = 200;
                playerMain_bedState = 200;
                playerUP_bedBar = 60;
                playerMain_bedBar = 60;
                spawnWood = false;
                spawnStone = false;
                spawnSmaragd_1 = false;
                spawnSmaragd_2 = false;
                spawnSmaragd_3 = false;
                spawnSmaragd_4 = false;
                loop_wood = 0;
                loop_stone = 0;
                loopSmaragd_1 = 0;
                loopSmaragd_2 = 0;
                loopSmaragd_3 = 0;
                loopSmaragd_4 = 0;
                woodCounter = 0;
                stoneCounter = 0;
                smaragdCounter_1 = 0;
                smaragdCounter_2 = 0;
                smaragdCounter_3 = 0;
                smaragdCounter_4 = 0;
                woodCounter_inv = 100;
                stoneCounter_inv = 100;
                leatherCounter_inv = 100;
                smaragdCounter_inv = 100;
                activateShop = false;
                speedPosionCount = 0;
                activateSpeedPoision = false;
                speedBoostApplied = false;
                drawSpeedPoision = false;
                leathersSet_1 = false;
                leathersSet_2 = false;
                leathersSet_3 = false;
                leathersSet_4 = false;
                leathersSet_5 = false;
                leathersSet_6 = false;
                leathersSet_7 = false;
                leathersSet_8 = false;
                leathersSet_9 = false;
                leathersSet_10 = false;
                leathersSet_11 = false;
                leathersSet_12 = false;
                leathersSet_13 = false;
                PlayerUP_leathersSet_1 = false;
                PlayerUP_leathersSet_2 = false;
                PlayerUP_leathersSet_3 = false;
                PlayerUP_leathersSet_4 = false;
                PlayerUP_leathersSet_5 = false;
                PlayerUP_leathersSet_6 = false;
                PlayerUP_leathersSet_7 = false;
                PlayerUP_leathersSet_8 = false;
                PlayerUP_leathersSet_9 = false;
                PlayerUP_leathersSet_10 = false;
                PlayerUP_leathersSet_11 = false;
                PlayerUP_leathersSet_12 = false;
                PlayerUP_leathersSet_13 = false;
                woodSpawnSpeed = 50;
                stoneSpawnSpeed = 300;
                smaragdSpawnSpeed = 500;               
                BedLvlPlayerMain = 1;               
                playerMove_Up = 0;
                playerMove_Down = 0;
                playerMove_Left = 0;
                playerMove_Right = 0;
                playerDircation_Up = false;
                playerDircation_Down = true;
                playerDircation_Left = false;
                playerDircation_Right = false;
            }
        }
    }
    function checkPlayerUpDirection() {
        if (!playerUP_diractionRight) {
            playerUpMove_Right = 0;
        }
        else if (!playerUP_diractionLeft) {
            playerUpMove_Left = 0;
        }
        else if (!playerUP_diractionDown) {
            playerUpMove_Down = 0;
        }
        else if (!playerUP_diractionUp) {
            playerUpMove_Up = 0;
        }

        //Check PlayerUP Direction
        if (mapPlayerUP_x > previousPlayerUP_x) {
            //console.log("PlayerUP Right");
            playerUP_diractionRight = true;
            playerUP_diractionLeft = false;
            playerUP_diractionDown = false;
            playerUP_diractionUp = false;
            playerUpMove_Right++;
            if (playerUpMove_Right >= targetFPS) {
                playerUpMove_Right = 0;
            }
        }
        else if (mapPlayerUP_x < previousPlayerUP_x) {
            //console.log("PlayerUP Left");
            playerUP_diractionRight = false;
            playerUP_diractionLeft = true;
            playerUP_diractionDown = false;
            playerUP_diractionUp = false;
            playerUpMove_Left++;
            if (playerUpMove_Left >= targetFPS) {
                playerUpMove_Left = 0;
            }
        }
        if (mapPlayerUP_y > previousPlayerUP_y) {
            //console.log("PlayerUP Down");
            playerUP_diractionRight = false;
            playerUP_diractionLeft = false;
            playerUP_diractionDown = true;
            playerUP_diractionUp = false;
            playerUpMove_Down++;
            if (playerUpMove_Down >= targetFPS) {
                playerUpMove_Down = 0;
            }
        }
        else if (mapPlayerUP_y < previousPlayerUP_y) {
            //console.log("PlayerUP UP");
            playerUP_diractionRight = false;
            playerUP_diractionLeft = false;
            playerUP_diractionDown = false;
            playerUP_diractionUp = true;
            playerUpMove_Up++;
            if (playerUpMove_Up >= targetFPS) {
                playerUpMove_Up = 0;
            }
        }


        previousPlayerUP_x = mapPlayerUP_x;
        previousPlayerUP_y = mapPlayerUP_y;

        //console.log("Right: " + playerUP_diractionRight + " " + playerUpMove_Right);
        //console.log("Left: " + playerUP_diractionLeft + " " + playerUpMove_Left);
        //console.log("UP: " + playerUP_diractionUp + " " + playerUpMove_Up);
        //console.log("Down: " + playerUP_diractionDown + " " + playerUpMove_Down);
    }
    function SFX_Directions() {
        if (playerIsMoving) {
            //BUTTOM ISLAND
            if ((map_x+2070 <= player_x) && (map_y+3820 <= player_y) &&
                (map_x+2920 >= player_x) && (map_y+4530 >= player_y)) {
                console.log("Grass");
                FootstepsGrass.play();
            }
            //PlayerUP Island
            if ((map_x+2050 <= player_x) && (map_y-100 <= player_y) &&
                (map_x+2920 >= player_x) && (map_y+620 >= player_y)) {
                console.log("Grass");
                FootstepsGrass.play();
            }
            //MIDDLE ISLAND
            if ((map_x+2000 <= player_x) && (map_y+1850 <= player_y) &&
                (map_x+2920 >= player_x) && (map_y+2570 >= player_y)) {
                console.log("Stone");
                FootstepsStone.play();
            }
            //BRIDGE BUTTOM ISLAND TO MIDDLE
            if ((map_x+2088+320 <= player_x) && (map_y+2570 <= player_y) &&
                (map_x+2088+420+50 >= player_x) && (map_y+3820 >= player_y)) {
                console.log("Wood");
                FootstepsWood.play();
            }
            //BRIDE PlayerUP ISLAND TO MIDDLE
            if ((map_x+2088+320 <= player_x) && (map_y+620 <= player_y) &&
                (map_x+2088+420+50 >= player_x) && (map_y+1850 >= player_y)) {
                console.log("Wood");
                FootstepsWood.play();
            }
            console.log("DOWN: " + playerDircation_Down)
            console.log("UP: " + playerDircation_Up)
            console.log("LEFT: " + playerDircation_Left)
            console.log("RIGHT: " + playerDircation_Right)
        }
    }
});